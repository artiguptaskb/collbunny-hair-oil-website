<?php
//set your razorpay account keyid and keysecret , 
//get from razorpay account in settings 
$keyId='rzp_test_69tDADHV4Ggjcy'; 
$keySecret='U8sqVkUzGJhWr54zVk3TO08q';
?>