<?php require_once("config.php"); $pid=$_GET['product_id'];
 $sql="SELECT count(*) from products WHERE pid=:pid"; 
    	 $stmt = $db->prepare($sql);
           $stmt->bindParam(':pid', $pid, PDO::PARAM_INT);
           $stmt->execute();
          $count=$stmt->fetchcolumn();
      if($count==0) 
      {
      	 header('location:index.php');
      	 exit();
      }
      ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Checkout - Techno Smarter </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-12 form-container">
				<h1>Checkout</h1>
<hr>
<?php 
if(isset($_POST['submit_form']))
{
$_SESSION['fname']=$_POST['fname']; 
$_SESSION['lname']=$_POST['lname']; 
$_SESSION['email']=$_POST['email']; 
$_SESSION['mobile']=$_POST['mobile']; 
$_SESSION['note']=$_POST['note']; 
$_SESSION['address']=$_POST['address']; 
$_SESSION['pid']=$pid;
if($_POST['email']!='')
{
header("location:pay.php");
}
}
?>		
				<div class="row"> 
					<div class="col-8"> 
<form action="" method="POST">
  <div class="mb-3">
    <label  class="label">First Name</label>
    <input type="text" class="form-control" name="fname" required>
  </div>
  <div class="mb-3">
    <label class="label">Last Name</label>
    <input type="text" class="form-control" name="lname" required>
  </div>

  <div class="mb-3">
    <label class="label">Email </label>
    <input type="email" class="form-control" name="email" required>
  </div>
  <div class="mb-3">
    <label class="label">Mobile</label>
    <input type="number" class="form-control" name="mobile" required>
  </div>
  <div class="mb-3">
    <label class="label">Address</label>
   <textarea name="address" class="form-control" name="address" required></textarea>
  </div>
  <div class="mb-3">
    <label class="label">Note</label>
   <textarea name="note" class="form-control" name="note"></textarea>
  </div>
					</div>
					<div class="col-4 text-center">
					<?php 
					 $sql="SELECT * from products WHERE pid=:pid"; 
         $stmt = $db->prepare($sql);
           $stmt->bindParam(':pid',$pid,PDO::PARAM_INT);
            $stmt->execute();
           $row=$stmt->fetch();
       echo '<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAugMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAACAwABBAUGB//EAEUQAAIBAwICBgUHCQYHAAAAAAECAAMEEQUhEjEGE0FRcYEHIjJh0SMkU4KRk8EUM1JUkqGx0vAXNkJywuEVFjVDYnSD/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAHxEBAQEBAAMBAQADAAAAAAAAAAECEQMhMRJBEyJR/9oADAMBAAIRAxEAPwD2DMrMHMrM5W4syZg5lEwAiYOZRMrMDWTBzKJg5gSEwSZCYJh0KJgZyNjLMwjeIuoG0b2ivEvwk2yFbxktFtCYxbGUKExbGETFsYiLaKYxjRTRAtjvEtGtEvAiXiXjniGgCWi4x4uAel5lZg5lZlLFmTMDMmYBZMrMomDmAWTBJlEyiYuhCZjXl7bWaB7qslNTy4jz8InV78WNm9RMGrg8IPLM80uL6ve3L1bmoXc9pMy8nk/PxnrfHpVO/oXlNjaVlcDmVO4+E5e4WpbdIrd1Yn1huTnx/jNRZ0L1agrWhYVV5FT/ABnR6STqd0tWvw8VvlnC8i5JH+mY3V8vP+pndOhJzAaWTAJnW1qiYpobRbGIgNFPGMYpzAFtEtGNFMYEU8S8a8Q8AU0XDaBAPRsyswSd5RMpYsysysysxBeZMwcyiYEsmCZRO0TcCq1JuofgqDdSRkeYgHL9NKN7jraal7c8yozweM57RLF61cbDHfjM6yj0npqz0b+gyVFPCxTcecy7OtplarmjTp06rdhGMzlszrX1lczrGTTazKOCoo4SN6i5B8AMCbGyorQpuFx61RmJAxk98bWqijRaoRkKM8I7T3Rdn1q2tEXHD13COs4TtxduPObTMy1kNfKKWccK97bD7Yj8oosQFq0yT2BxH9OP7qXH+WnPFNEAHSrTyAPz6ysa/SueuvZCYsmExi2jRQsYtoTRbGALaKaMaJaALcxLxjGKeBFNFwmgQD0IneQmBneQmNQsyiYOZWYAWZWYOZMwCydoOd5RMEmAaTVej9C9vRdo3DUb84vLi980+qaPd2gWraU3emm5wwJX3zsiZi6jTq1tPuaVs3DWekyo2cYOJjrxZvtNzK4nVOmFyVo0bcIr0gDVqMM8TjuHLHb4xNp0t1SrcUadS4Vg7qp+SXv8JorXRr2tUAaiyY/S2GJvNH6J393eUWooWSm6l3Pqqu+fOZdtT7ehdOGP/KtwOBgOGnucfGeL6J/enTv/AGFntfSujXvtDq2VOmyuwQBm5bTzfTOhuoW+t2t49e26qjVDtuc4+ya+LU7XTy/h3rGLYw2yvOKaaxlQsYtoTRbQILHeIeMYxLmALYxTmMaJaBFsYGYTRcA9AzKJg5kJjULMrMHMomAWTJmCTKzEFkwcyE7QTALJ2mPe1lo0N2CtUYU0z2s2w/r3TV9JukFLRKKBVFS6qA9WnYPefdOMTpRqdSuterchihJVTTXhXPcMf7yN7k9FdSPR2pUmVVNMcKjC5HITfaHwUbIU6aBVyTt4zhNC6SU9RqC3rqtOuR6vD7LfAzuNIPzcR4s9cOcsY+vVcpju905lajiqOEkec6DWzOdB+VEjdv6ayejbes9S4rq7EheHA7uccxmJZn5zc/V/GZJl5+I19C0WxhMYtjGkDGKaGximMCLaKYw2MU0YLcxcJjF5gHfZkzBJlZgoWZRMHMmYBZMrMrMrMAvMonETdXNO2ompVYADvM5ev0zKXS0qdmKqFsbPhpF3JeJtkaH0iW9ZNdWqQTTrUhwHs9XYj9/75y5qcGwOffPWbVtM1+g1crTuAfUw/tUh7u7vyJz2sdB3rb6dcoB+jWG48xIubajUv8crpFy9K5pujYKsDk+6e86M4e1VhyYZnmOj9BltSKmoXfWMD+bpLhfMnc/YJ6bo+Ba4HLG0rMs0vxSzvWDrhnOK3yom+15sGc2r/KiRv66J8ZFmfnNx9X8ZlMZhWJ+cXP1fxmUxmmfjLX1TGKYwmMWxlJAximMNjFMYEBjEsYxzEsYwBjF5EtjF5gHfEyswSZWYKHmVmDmUTACzKzBzEXVZ6IV1HEmcMO2K3ga3XENdmpOMrgYBnCalZvaNmnxMjZVnx7Of8PxnouqYeivVkdcxCp3ec0VO2Dirb3S4pVRwuT2Hsby2nHr/AF39Rca78aDRrutpdzTuFzwn21/TWejK4dFdTlWAIPunB2dlUekadbhV1bgyTtt2+E7K2elRtqVIVAQiBc9+Jt49y9Vnx7n2MkmbrRz838pzxuKX6Ym80WorW+QcgjaadnZ7aTNn8a3pC2DOaV/lB4ze9JGqFsJTdvBZzKdf1m9Fx9UzHWp1vnF42Vgfl7n6v4zLYzXWVQU61brTwcXDji2zzmS1xR+lT9qa5s4w3m9MJi2ME16R5VE+2CWB5EHwMtHKpjFsYRMUxgQGMUxhsYljGAMYvMtzAzAO7JkzJ1dX6Kp+wZXV1voan7Jga8zGvr+1sKPW3dZaSdmdyfADczI6qt9DU/ZM0XSnSLi+oU6q06h6rPEvCeXfI3bJ2FWXp+v6dqNTq7auS/YroVz4Zm0pqajhV85xGmaSqvTKBy+RgAb5nXotxRTjqo6sRw7A4Hn2zGeX95vo/F3VD0gubPTdOq3FVKWQMLlR6zdgE5bQaGp6jVo0qzcJYB6pAGKadnmZldI7n54odRVFBOJUbccZ7fIY+2dDoxSxs1GM1Kg4qrdrNj+hMpJq+3o9/GGZ/wAHsFUZtx5mYd1aWdIerSAPIAGZNbUUGxznxmp1DUqSUnqf4sZUCa6uJPUY5m7foGpW/H6owo5kd81tbULm2Dii/qAnhUnaJOooaeKWXcgHc4yYFzUp8ODg4EiNLLPRdbUrxvWNTh8JrbvW7ykpYVyoHMkyXF0GHq42zOf1auahFIbdrbcprnMK1j1te1K/udqiuucAsmcDzmM2sXoyA9PAPMUxFlhkU6A4VA3Ii6ahjy9VeXvM3kjG2njUdQK+tXKn/wAVUfhBt9SuqWoW9Z7ioVSopILHHMZ28Ip8mDStnuKq0kGWdgAB2zSSMtdevM2d4pjGdRcBQDQq7DHsGA1Cv9BW+7MzZkuYlzHtQuP1et92Yl6Fx+r1vuzAEMYGYxre4/V633Zgfk1z+rVvuzAPYOAd0rgHdLLSuKW0TgHdAakD2sPAw+KDxSabVvoFv1wqUbi4oHJPyTKN/NYx9NTqir3Vw47eOpn8JnloJbOxk/mT+HOR5V0zV7K+DsyuhHCWXke6bG21qlcUUqJU2IGR3e6d1c2lrcqVr29Kop5hlBzNU/RTQWJI06lTJ+jyv8JlfDP42/y9nK5S41Icb4bs2mh1XVCy4Vjk+r4Tv63QvRKm/VV1/wAtdhMG49HeiVudS9Xwrn8ZP+Fc8uY4SneLTZF4hz/r+El3qYxgMOIzsqno10huV5qC47qi/CYz+i/SydtR1AfWT+WaTxSJ15euGq3wp085BIE0lxdF85b1mOTPTn9FemNz1PUPtT+WJPok0rP/AFK/P1k/lmkmYyu7f48yauqIe8xZuQiY4hmeof2S6R2398frj4Sf2TaLne5vG/8AoPhLlyzt1XlLXgHbN30Q1PT7LVEvtTZuCjvSRVzlu8+4TvV9FGgrza5bxqR9P0aaHS9lKh8Xj/WOcTza09IWjP8A95h4oRMin0z0ur7FcfZJT6A6KnKhnxMyafRHS6P5u3UTOzK5+v6idIrSp7D58o1dWovyP7oaaDZ0/YpgRo0ugo2WR7X6LF7TblL/AClY0WNMchL/ACNO6HscjrpRkkmzNUHMkkAHMo85JIjCZRkkiMBMomSSIKMEySQAYJlyRAMoySQMJlGSSIKgmSSBhlGSSADiViSSAf/Z" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">'.$row['title'].'</h5>
    <p class="card-text">'.$row['price'].' INR</p>
  </div>
</div>';
				?> 
				<br>
				  <button type="submit" class="btn btn-primary" name="submit_form">Place Order</button>
	</form>
				</div>
				</div>
		</div>
	</div>
</div>
</body>
</html>