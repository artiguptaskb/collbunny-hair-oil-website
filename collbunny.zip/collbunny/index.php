<!DOCTYPE html>
<html lang="en">
    <head>
        <!--sp-funnel-tracking-services-->
        <!-- Google Analytics -->
        <script>
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }
                ,
                i[r].l = 1 * new Date();
                a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            }
            )(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
            ga('create', 'G-DNV025B5D5', 'auto');
            ga('send', 'pageview');
        </script>
        <!-- End Google Analytics -->
        <script>
            !function(f, b, e, v, n, t, s) {
                if (f.fbq)
                    return;
                n = f.fbq = function() {
                    n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                }
                ;
                if (!f._fbq)
                    f._fbq = n;
                n.push = n;
                n.loaded = !0;
                n.version = '2.0';
                n.queue = [];
                t = b.createElement(e);
                t.async = !0;
                t.src = v;
                s = b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t, s)
            }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '304709863675708');
            fbq('track', 'PageView');
        </script>
        <noscript>
            <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=304709863675708&ev=PageView&noscript=1">
        </noscript>
        <!--/sp-funnel-tracking-services-->
        <!--sp-funnel-head-settings-->
        <title>Hiran Pain Oil</title>
        <!--/sp-funnel-head-settings-->
        <!--sp-tracking-page-head-->
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-DNV025B5D5"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());

            gtag('config', 'G-DNV025B5D5');
        </script>
        <script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
        <!--/sp-tracking-page-head-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:800,700,600|Montserrat:700|Open Sans:700&display=swap">
        <style>
            a,body,div,h1,h2,h5,h6,html,img,li,p,span,ul,video {
                margin: 0;
                padding: 0;
                border: 0;
                font-size: 100%;
                font: inherit;
                vertical-align: baseline
            }

            body {
                line-height: 1
            }

            ul {
                list-style: none
            }

            a,a:hover,a:visited {
                text-decoration: none;
                cursor: pointer
            }

            body {
                overflow-x: hidden;
                -webkit-font-smoothing: antialiased
            }

            p {
                margin-bottom: 20px
            }

            p:last-child {
                margin-bottom: 0
            }

            img {
                max-width: 100%;
                border: 0;
                -ms-interpolation-mode: bicubic;
                vertical-align: middle;
                height: auto
            }

            ul {
                list-style: disc;
                padding-left: 1.3em
            }

            .HD:after,.HD:before {
                content: " ";
                display: table
            }

            .HD:after {
                clear: both
            }

            a {
                color: #1b86f1
            }

            .ID {
                position: relative;
                -webkit-box-sizing: border-box;
                box-sizing: border-box
            }

            .JD,.KD {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%
            }

            .KD {
                z-index: 0;
                overflow: hidden
            }

            .LD {
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
                width: 100%
            }

            .MD {
                position: relative;
                z-index: 2
            }

            .ND {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%
            }

            .OD {
                position: relative;
                padding: 0 10px;
                z-index: 2;
                margin-bottom: 25px
            }

            .OD,.PD {
                margin-left: auto;
                margin-right: auto
            }

            .PD {
                width: 100%;
                max-width: 1180px
            }

            .QD {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                margin: 0 -25px;
                -webkit-box-align: start;
                -ms-flex-align: start;
                align-items: flex-start;
                -webkit-box-orient: horizontal;
                -webkit-box-direction: normal;
                -ms-flex-direction: row;
                flex-direction: row;
                -ms-flex-wrap: nowrap;
                flex-wrap: nowrap
            }

            .RD>.OD>.QD {
                -webkit-box-align: stretch;
                -ms-flex-align: stretch;
                -ms-grid-row-align: stretch;
                align-items: stretch
            }

            .SD>.OD>.QD {
                margin-left: -5px;
                margin-right: -5px
            }

            .TD>.OD>.QD {
                margin-left: -25px;
                margin-right: -25px
            }

            .UD>.OD>.QD {
                margin-left: -35px;
                margin-right: -35px
            }

            .VD>.OD>.QD {
                margin-left: -10px;
                margin-right: -10px
            }

            .WD {
                padding: 0 15px;
                position: relative;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }

            .RD>.OD>.QD>.WD {
                -webkit-box-align: stretch;
                -ms-flex-align: stretch;
                align-items: stretch
            }

            .tatsu-column-inner {
                width: 100%;
                position: relative;
                border-style: solid;
                border-color: transparent;
                -webkit-transition: -webkit-box-shadow .3s ease,-webkit-transform .3s ease;
                transition: -webkit-box-shadow .3s ease,-webkit-transform .3s ease;
                -o-transition: box-shadow .3s ease,transform .3s ease;
                transition: box-shadow .3s ease,transform .3s ease;
                transition: box-shadow .3s ease,transform .3s ease,-webkit-box-shadow .3s ease,-webkit-transform .3s ease;
                padding: 10px
            }

            .XD {
                width: 100%
            }

            .RD>.OD>.QD>.WD>.tatsu-column-inner {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }

            .RD>.OD>.QD>.YD>.tatsu-column-inner {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center
            }

            .RD>.OD>.QD>.ZD>.tatsu-column-inner {
                -webkit-box-align: start;
                -ms-flex-align: start;
                align-items: flex-start
            }

            .SD>.OD>.QD>.WD {
                padding: 0
            }

            .SD>.OD>.QD>.WD>.tatsu-column-inner {
                padding: 5px
            }

            .TD>.OD>.QD>.WD {
                padding: 0 15px
            }

            .UD>.OD>.QD>.WD {
                padding: 0 25px
            }

            .aD>.OD>.QD>.bD {
                padding: 0
            }

            .bD {
                width: 100%
            }

            .cD {
                width: 33.33%
            }

            .dD {
                width: 50%
            }

            .XD {
                position: relative;
                z-index: 2
            }

            .eD {
                z-index: 0;
                overflow: hidden
            }

            .eD,.fD {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%
            }

            .gD>.aD {
                margin: 0 -10px
            }

            .ID .aD:last-child>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h1:last-child,.ID .aD:last-child>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h2:last-child,.ID .aD:last-child>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h3:last-child,.ID .aD:last-child>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h4:last-child,.ID .aD:last-child>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h5:last-child,.ID .aD:last-child>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h6:last-child {
                margin-bottom: 0
            }

            .ID .aD:not(:last-child)>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h1:last-child,.ID .aD:not(:last-child)>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h2:last-child,.ID .aD:not(:last-child)>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h3:last-child,.ID .aD:not(:last-child)>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h4:last-child,.ID .aD:not(:last-child)>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h5:last-child,.ID .aD:not(:last-child)>.OD>.QD>.WD>.tatsu-column-inner>.XD>.gD>h6:last-child {
                margin-bottom: 20px
            }

            .gD {
                width: 100%;
                -webkit-box-sizing: border-box;
                box-sizing: border-box
            }

            .tatsu-module {
                margin-bottom: 50px
            }

            .hD {
                -webkit-box-sizing: border-box;
                box-sizing: border-box
            }

            .iD {
                text-align: center
            }

            .jD {
                text-align: left
            }

            @media only screen and (max-width: 1366px) {
                .QD {
                    -ms-flex-wrap:wrap;
                    flex-wrap: wrap
                }
            }

            @media only screen and (min-width: 1025px) and (max-width:1220px) {
                .PD {
                    max-width:calc(100% - 60px)
                }
            }

            @media only screen and (min-width: 960px) and (max-width:1024px) {
                .PD {
                    max-width:900px
                }
            }

            @media only screen and (min-width: 768px) and (max-width:959px) {
                .PD {
                    max-width:740px
                }
            }

            @media only screen and (max-width: 767px) {
                .PD {
                    max-width:90vw
                }

                .OD {
                    padding: 0;
                    margin-bottom: 45px
                }

                .kD {
                    margin-bottom: 0
                }

                .gD>.aD {
                    margin: 0
                }

                .aD .OD .QD {
                    -webkit-box-orient: vertical;
                    -webkit-box-direction: normal;
                    margin-left: 0;
                    margin-right: 0
                }

                .WD {
                    margin: 0 0 45px
                }

                .aD>.OD>.QD>.WD,.aD>.OD>.QD>.WD>.tatsu-column-inner {
                    padding: 0
                }

                .ID .aD:last-child>.OD>.QD>.WD>.tatsu-column-inner {
                    margin-bottom: 0
                }
            }

            @media only screen and (min-width: 480px) and (max-width:767px) {
                .PD {
                    max-width:440px
                }
            }

            .lD:after,.lD:before {
                content: " ";
                display: table
            }

            .lD:after {
                clear: both
            }

            strong {
                font-weight: 600
            }

            html {
                overflow-x: hidden
            }

            .tatsu-single-image-inner {
                overflow: hidden;
                border-style: solid
            }

            .kD {
                margin-bottom: 0
            }

            .ID {
                width: 100%
            }

            * {
                -webkit-box-sizing: border-box;
                box-sizing: border-box
            }

            .mD {
                margin-bottom: 30px
            }

            .hD.nD {
                margin-left: auto;
                margin-right: auto
            }

            .oD {
                margin: 0 0 30px
            }

            .oD:last-child {
                margin-right: 0
            }

            .pD {
                text-decoration: none;
                border-color: transparent
            }

            .pD>div {
                text-align: center
            }

            .oD .qD {
                cursor: pointer;
                overflow: hidden
            }

            .pD,.qD,.rD {
                display: inline-block
            }

            .pD,.qD,.rD,.sD {
                position: relative
            }

            .sD {
                display: block
            }

            .pD {
                padding: 15px 36px
            }

            .oD .pD:after,.oD .pD:before,.oD .qD:after,.oD .qD:before,.oD .rD:after,.oD .sD:after {
                content: "";
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1
            }

            .oD .pD {
                background-clip: padding-box
            }

            .qD:after,.qD:before {
                border-style: solid;
                border-color: transparent;
                -webkit-box-sizing: border-box;
                box-sizing: border-box
            }

            .oD .rD span,.oD .sD span {
                display: inline-block
            }

            .oD .rD:after,.oD .sD:after {
                content: attr(data-text);
                font: inherit
            }

            .oD .pD:after,.oD .pD:before,.oD .qD:after,.oD .qD:before,.oD .rD:after,.oD .rD span,.oD .sD:after,.oD .sD span {
                -webkit-transition: all .3s linear;
                -o-transition: .3s all linear;
                transition: all .3s linear
            }

            .oD .pD:before,.oD .qD:before,.oD .rD span,.oD .sD span {
                opacity: 1
            }

            .oD .pD:after,.oD .qD:after,.oD .qD:hover .pD:before,.oD .qD:hover .rD span,.oD .qD:hover .sD span,.oD .qD:hover:before,.oD .rD:after,.oD .sD:after {
                opacity: 0
            }

            .oD .qD:hover .pD:after,.oD .qD:hover .rD:after,.oD .qD:hover .sD:after,.oD .qD:hover:after {
                opacity: 1
            }

            .rD,.sD {
                z-index: 1
            }

            .oD.tD .pD,.oD.tD .pD:after,.oD.tD .pD:before,.oD.tD .qD,.oD.tD .qD:after,.oD.tD .qD:before {
                border-radius: 3px
            }

            .uD {
                padding: 14px 25px
            }

            .vD {
                padding: 16px 42px
            }

            .wD {
                padding: 18px 51px
            }

            .xD {
                margin-bottom: 15px
            }

            .yD {
                display: inline-block;
                position: relative;
                vertical-align: middle
            }

            .yD svg,.zD svg {
                fill: currentColor
            }

            .yD {
                border-width: 0;
                border-style: solid;
                -webkit-transition: all .3s linear;
                -o-transition: all .3s linear;
                transition: all .3s linear
            }

            .yD:before {
                position: absolute;
                top: 50%;
                left: 50%;
                -webkit-transform: translate(-50%,-50%);
                -ms-transform: translate(-50%,-50%);
                transform: translate(-50%,-50%)
            }

            .xD {
                margin-bottom: 20px
            }

            .AE {
                line-height: 0
            }

            .xD a {
                display: inline-block
            }

            .yD.BE {
                font-size: 48px
            }

            .yD.CE {
                font-size: 62px
            }

            .yD.BE.DE {
                font-size: 68px
            }

            .yD.CE.DE {
                font-size: 86px
            }

            .yD.BE {
                width: 80px;
                height: 80px
            }

            .yD.CE {
                width: 100px;
                height: 100px
            }

            .yD.DE {
                width: auto;
                height: auto;
                line-height: 1
            }

            .EE .yD.DE:before {
                position: static
            }

            .xD {
                -webkit-transform: none;
                -ms-transform: none;
                transform: none
            }

            span.yD {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                justify-content: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center
            }

            span.yD svg {
                height: 1em;
                width: 1em
            }

            .EE {
                -webkit-transition: all .3s ease;
                -o-transition: all .3s ease;
                transition: all .3s ease
            }

            .FE {
                display: inline-block;
                border: none
            }

            hr.FE {
                margin: 0
            }

            .GE {
                margin-bottom: 20px;
                overflow: hidden
            }

            .GE,.HE {
                line-height: 0
            }

            .HE {
                width: 100%;
                margin: 0 0 30px
            }

            .tatsu-image-lazyload img {
                opacity: 0;
                -webkit-transition: opacity .3s ease;
                -o-transition: opacity .3s ease;
                transition: opacity .3s ease
            }

            .tatsu-single-image-inner {
                display: inline-block;
                position: relative
            }

            .HE img {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
                border: 0 solid transparent;
                -o-object-fit: cover;
                object-fit: cover
            }

            .HE.jD {
                text-align: left
            }

            .HE.iD {
                text-align: center
            }

            @media only screen and (max-width: 767px) {
                .HE.tatsu-module .tatsu-single-image-inner {
                    max-width:100%;
                    -webkit-transform: translateZ(0);
                    transform: translateZ(0)
                }
            }

            @media only screen and (max-width: 767px) {
                .hD {
                    width:100%
                }
            }

            .IE {
                white-space: nowrap;
                line-height: 0
            }

            .JE {
                display: inline-block;
                position: relative
            }

            .KE,.LE {
                line-height: 0;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }

            .KE {
                position: absolute;
                overflow: hidden;
                left: 0;
                top: 0
            }

            .ME {
                margin-right: 2px
            }

            .ME:last-child {
                margin-right: 0
            }

            .NE {
                text-align: left
            }

            .OE {
                text-align: center
            }

            .ME svg {
                fill: currentColor;
                width: 18px;
                height: 18px
            }

            .countdown-section {
                line-height: 1
            }

            .PE {
                margin: 0 0 40px
            }

            .QE {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-align: start;
                -ms-flex-align: start;
                align-items: flex-start
            }

            .QE .zD {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 auto;
                flex: 0 0 auto
            }

            .RE {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center
            }

            .QE.SE .zD {
                margin-right: 16px
            }

            .QE.TE .zD {
                margin-right: 18px
            }

            .QE.UE .zD {
                margin-right: 21px
            }

            .VE {
                border-radius: 50%
            }

            .WE {
                margin-bottom: .5em
            }

            .WE a {
                color: inherit
            }

            .XE>:last-child {
                margin-bottom: 0
            }

            .zD {
                line-height: 0;
                background-position: 50%;
                background-repeat: no-repeat;
                fill: currentColor
            }

            .SE svg {
                width: 22px;
                height: 22px
            }

            .TE svg {
                width: 32px;
                height: 32px
            }

            .UE svg {
                width: 45px;
                height: 45px
            }

            .SE.YE svg {
                width: 16px;
                height: 16px
            }

            .UE.YE svg {
                width: 28px;
                height: 28px
            }

            .ZE>:last-child {
                margin-bottom: 0
            }

            .QE.PE>:last-child {
                margin-right: 0
            }

            .VE {
                line-height: 0;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                justify-content: center;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center
            }

            .YE.SE .VE {
                width: 38px;
                height: 38px
            }

            .YE.UE .VE {
                width: 64px;
                height: 64px
            }

            @media only screen and (max-width: 768px) {
                .QE.UE .zD {
                    margin-right:18px
                }
            }

            .be-start-animation {
                -o-transition: -o-transform .7s,-o-scale .7s,opacity .7s;
                -webkit-transition: -webkit-transform .7s,-webkit-scale .7s,opacity .7s;
                -webkit-transition: scale .7s,opacity .7s,-webkit-transform .7s;
                transition: scale .7s,opacity .7s,-webkit-transform .7s;
                -o-transition: transform .7s,scale .7s,opacity .7s;
                transition: transform .7s,scale .7s,opacity .7s;
                transition: transform .7s,scale .7s,opacity .7s,-webkit-transform .7s
            }

            .be-col {
                padding: 0;
                margin: 0
            }

            .be-grid.be-grid-initialized {
                visibility: visible
            }

            .be-col {
                -webkit-box-flex: 0;
                -ms-flex: 0 0 auto;
                flex: 0 0 auto;
                padding: 0 15px;
                width: 33.33%;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
                margin-bottom: 30px
            }

            .be-lazy-load {
                opacity: 0;
                -webkit-transition: opacity .5s;
                -o-transition: opacity .5s;
                transition: opacity .5s
            }

            .be-lazy-loaded {
                opacity: 1
            }

            .be-col-hide {
                opacity: 0;
                -webkit-transform: translate3d(0,100px,0);
                transform: translate3d(0,100px,0)
            }

            .be-col-visible {
                opacity: 1;
                -webkit-transform: translateZ(0);
                transform: translateZ(0);
                -webkit-transition: opacity .5s;
                -o-transition: opacity .5s;
                transition: opacity .5s
            }

            .tatsu-accordion-inner {
                -webkit-transition: opacity .3s;
                -o-transition: opacity .3s
            }

            .tatsu-accordion .tatsu-accordion-expand {
                margin-right: 0;
                float: right;
                margin-top: 5px;
                margin-left: auto
            }

            .tatsu-accordion-expand:after,.tatsu-accordion-expand:before {
                position: absolute;
                top: 50%;
                content: "";
                display: block;
                background: currentColor;
                left: 50%
            }

            .tatsu-accordion-expand:before {
                -webkit-transition: opacity .25s,-webkit-transform .25s;
                transition: opacity .25s,-webkit-transform .25s;
                -o-transition: opacity .25s,transform .25s;
                transition: opacity .25s,transform .25s,-webkit-transform .25s
            }

            .aE>p:last-child {
                margin: 0
            }

            .tatsu-accordion-style1 .bE {
                padding: 0 25px 15px;
                -webkit-box-shadow: 0 4px 6px rgba(0,0,0,.1);
                box-shadow: 0 4px 6px rgba(0,0,0,.1);
                border-style: solid;
                border-width: 1px;
                border-top: 0;
                border-bottom-left-radius: 3px;
                border-bottom-right-radius: 3px
            }

            .accordion-head {
                border-color: currentColor
            }

            .be-embed-placeholder,.tatsu-video-placeholder {
                position: relative
            }

            .be-embed-placeholder:before {
                content: "";
                padding-top: 56.25%;
                display: block
            }

            .tatsu-video-placeholder {
                padding-top: 56.25%
            }

            .poster-video {
                display: block
            }

            .cE {
                width: 100%;
                height: 100%;
                z-index: 1;
                -o-object-fit: cover;
                object-fit: cover;
                top: 0;
                cursor: pointer
            }

            .cE,.dE {
                position: absolute
            }

            .dE {
                top: 50%;
                left: 50%;
                -webkit-transform: translate(-50%,-50%);
                -ms-transform: translate(-50%,-50%);
                transform: translate(-50%,-50%);
                z-index: 2;
                width: 5em;
                height: 5em;
                border: 5px solid rgba(0,0,0,.1);
                border-radius: 50%
            }

            span.tatsu-form-range-tooltip.tatsu-form-range-show {
                display: inline-block
            }

            .countdown-section,.tatsu-form-validate-show {
                display: block
            }

            .tatsu-single-image-inner amp-img img {
                -o-object-fit: cover;
                object-fit: cover
            }

            .eE {
                margin: 0 0 20px
            }

            .fE,.gE {
                margin: 0 0 12px
            }

            .hE {
                margin: 0
            }

            .iE {
                margin: 0 auto
            }

            .tatsu-header {
                width: 100%;
                z-index: 6
            }

            .jE {
                position: relative;
                overflow: hidden
            }

            .kE {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }

            .kE.PD {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center
            }

            .lE .kE {
                -webkit-box-pack: justify;
                -ms-flex-pack: justify;
                justify-content: space-between
            }

            .mE {
                border-radius: 5px
            }

            .nE {
                -webkit-transition: background-color .3s ease;
                -o-transition: background-color .3s ease;
                transition: background-color .3s ease
            }

            .nE .pD {
                line-height: 1
            }

            .kE.PD {
                position: relative
            }

            .tatsu-mobile-menu {
                position: absolute;
                top: 100%;
                width: 100%;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                -ms-flex-direction: column;
                flex-direction: column;
                z-index: 5;
                height: 0;
                overflow: hidden
            }

            .oE img {
                width: 100%
            }

            .open.tatsu-mobile-menu {
                height: auto
            }

            @media only screen and (min-width: 1024px) {
                .tatsu-mobile-menu {
                    display:none
                }
            }

            @media only screen and (max-width: 1024px) {
                .tatsu-header-menu {
                    display:none
                }

                .tatsu-mobile-menu {
                    display: -webkit-box;
                    display: -ms-flexbox;
                    display: flex
                }

                .nE {
                    margin-right: 10px;
                    margin-left: auto
                }
            }

            .tatsu-mobile-menu {
                background: #fff
            }

            video {
                width: auto;
                max-width: 100%
            }

            .tatsu-module.pE {
                overflow: hidden;
                position: relative
            }

            .qE {
                margin-bottom: 0
            }

            .rE {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center
            }

            .rE.SE svg {
                width: 12px;
                height: 12px
            }

            .rE.SE .VE {
                width: 22px;
                height: 22px
            }

            .rE.YE .VE {
                border-radius: 50%
            }

            .rE {
                margin-bottom: 10px
            }

            .white-popup {
                max-width: 900px;
                margin: 20px auto;
                position: relative
            }

            .nE {
                background-color: #5ea314;
                border-image: none;
                border: 1px solid #2abc8a
            }

            .nE:hover {
                background-color: #2abc8a;
                border-image: none;
                border-color: #2abc8a
            }

            .nE .pD,.nE .pD:hover {
                color: #fff
            }

            .kE {
                height: 120px
            }

            .jE {
                background: #fcfbf8
            }

            .oE {
                width: 164px
            }

            .tatsu-header {
                position: relative
            }

            @media only screen and (max-width: 767px) {
                .kE {
                    height:100px
                }

                .oE {
                    width: 150px
                }
            }

            .tatsu-amp-bg-video video {
                object-fit: cover
            }

            .mfp-bg {
                z-index: 1042;
                overflow: hidden;
                background: #0b0b0b;
                opacity: .8
            }

            .mfp-bg,.mfp-wrap {
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                position: fixed
            }

            .mfp-wrap {
                z-index: 1043;
                outline: none!important;
                -webkit-backface-visibility: hidden
            }

            .mfp-container {
                text-align: center;
                position: absolute;
                width: 100%;
                height: 100%;
                left: 0;
                top: 0;
                padding: 0 8px;
                box-sizing: border-box
            }

            .mfp-container:before {
                content: "";
                display: inline-block;
                height: 100%;
                vertical-align: middle
            }

            .mfp-align-top .mfp-container:before {
                display: none
            }

            .mfp-content {
                position: relative;
                display: inline-block;
                vertical-align: middle;
                margin: 0 auto;
                text-align: left;
                z-index: 1045
            }

            .mfp-ajax-holder .mfp-content,.mfp-inline-holder .mfp-content {
                width: 100%;
                cursor: auto
            }

            .mfp-ajax-cur {
                cursor: progress
            }

            .mfp-zoom-out-cur,.mfp-zoom-out-cur .mfp-image-holder .mfp-close {
                cursor: -moz-zoom-out;
                cursor: -webkit-zoom-out;
                cursor: zoom-out
            }

            .mfp-zoom {
                cursor: pointer;
                cursor: -webkit-zoom-in;
                cursor: -moz-zoom-in;
                cursor: zoom-in
            }

            .mfp-auto-cursor .mfp-content {
                cursor: auto
            }

            .mfp-arrow,.mfp-close,.mfp-counter,.mfp-preloader {
                -webkit-user-select: none;
                -moz-user-select: none;
                user-select: none
            }

            .mfp-loading.mfp-figure {
                display: none
            }

            .mfp-hide {
                display: none!important
            }

            .mfp-preloader {
                color: #ccc;
                position: absolute;
                top: 50%;
                width: auto;
                text-align: center;
                margin-top: -.8em;
                left: 8px;
                right: 8px;
                z-index: 1044
            }

            .mfp-preloader a {
                color: #ccc
            }

            .mfp-preloader a:hover {
                color: #fff
            }

            .mfp-s-error .mfp-content,.mfp-s-ready .mfp-preloader {
                display: none
            }

            button.mfp-arrow,button.mfp-close {
                overflow: visible;
                cursor: pointer;
                background: transparent;
                border: 0;
                -webkit-appearance: none;
                display: block;
                outline: none;
                padding: 0;
                z-index: 1046;
                box-shadow: none;
                touch-action: manipulation
            }

            button::-moz-focus-inner {
                padding: 0;
                border: 0
            }

            .mfp-close {
                width: 44px;
                height: 44px;
                line-height: 44px;
                position: absolute;
                right: 0;
                top: 0;
                text-decoration: none;
                text-align: center;
                opacity: .65;
                padding: 0 0 18px 10px;
                color: #fff;
                font-style: normal;
                font-size: 28px;
                font-family: Arial,Baskerville,monospace
            }

            .mfp-close:focus,.mfp-close:hover {
                opacity: 1
            }

            .mfp-close:active {
                top: 1px
            }

            .mfp-close-btn-in .mfp-close {
                color: #333
            }

            .mfp-iframe-holder .mfp-close,.mfp-image-holder .mfp-close {
                color: #fff;
                right: -6px;
                text-align: right;
                padding-right: 6px;
                width: 100%
            }

            .mfp-counter {
                position: absolute;
                top: 0;
                right: 0;
                color: #ccc;
                font-size: 12px;
                line-height: 18px;
                white-space: nowrap
            }

            .mfp-arrow {
                position: absolute;
                opacity: .65;
                top: 50%;
                margin: -55px 0 0;
                padding: 0;
                width: 90px;
                height: 110px;
                -webkit-tap-highlight-color: transparent
            }

            .mfp-arrow:active {
                margin-top: -54px
            }

            .mfp-arrow:focus,.mfp-arrow:hover {
                opacity: 1
            }

            .mfp-arrow:after,.mfp-arrow:before {
                content: "";
                display: block;
                width: 0;
                height: 0;
                position: absolute;
                left: 0;
                top: 0;
                margin-top: 35px;
                margin-left: 35px;
                border: inset transparent
            }

            .mfp-arrow:after {
                border-top-width: 13px;
                border-bottom-width: 13px;
                top: 8px
            }

            .mfp-arrow:before {
                border-top-width: 21px;
                border-bottom-width: 21px;
                opacity: .7
            }

            .mfp-arrow-left {
                left: 0
            }

            .mfp-arrow-left:after {
                border-right: 17px solid #fff;
                margin-left: 31px
            }

            .mfp-arrow-left:before {
                margin-left: 25px;
                border-right: 27px solid #3f3f3f
            }

            .mfp-arrow-right {
                right: 0
            }

            .mfp-arrow-right:after {
                border-left: 17px solid #fff;
                margin-left: 39px
            }

            .mfp-arrow-right:before {
                border-left: 27px solid #3f3f3f
            }

            .mfp-iframe-holder {
                padding-top: 40px;
                padding-bottom: 40px
            }

            .mfp-iframe-holder .mfp-content {
                line-height: 0;
                width: 100%;
                max-width: 900px
            }

            .mfp-iframe-holder .mfp-close {
                top: -40px
            }

            .mfp-iframe-scaler {
                width: 100%;
                height: 0;
                overflow: hidden;
                padding-top: 56.25%
            }

            .mfp-iframe-scaler iframe {
                position: absolute;
                display: block;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                box-shadow: 0 0 8px rgba(0,0,0,.6);
                background: #000
            }

            img.mfp-img {
                width: auto;
                max-width: 100%;
                height: auto;
                display: block;
                box-sizing: border-box;
                padding: 40px 0;
                margin: 0 auto
            }

            .mfp-figure,img.mfp-img {
                line-height: 0
            }

            .mfp-figure:after {
                content: "";
                position: absolute;
                left: 0;
                top: 40px;
                bottom: 40px;
                display: block;
                right: 0;
                width: auto;
                height: auto;
                z-index: -1;
                box-shadow: 0 0 8px rgba(0,0,0,.6);
                background: #444
            }

            .mfp-figure small {
                color: #bdbdbd;
                display: block;
                font-size: 12px;
                line-height: 14px
            }

            .mfp-figure figure {
                margin: 0
            }

            .mfp-bottom-bar {
                margin-top: -36px;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                cursor: auto
            }

            .mfp-title {
                text-align: left;
                line-height: 18px;
                color: #f3f3f3;
                word-wrap: break-word;
                padding-right: 36px
            }

            .mfp-image-holder .mfp-content {
                max-width: 100%
            }

            .mfp-gallery .mfp-image-holder .mfp-figure {
                cursor: pointer
            }

            .mfp-close-btn-in .white-popup .mfp-close {
                color: #fff
            }

            .white-popup video {
                width: 100%
            }

            @media screen and (max-height: 300px),screen and (max-width:800px) and (orientation:landscape) {
                .mfp-img-mobile .mfp-image-holder {
                    padding-left:0;
                    padding-right: 0
                }

                .mfp-img-mobile img.mfp-img {
                    padding: 0
                }

                .mfp-img-mobile .mfp-figure:after {
                    top: 0;
                    bottom: 0
                }

                .mfp-img-mobile .mfp-figure small {
                    display: inline;
                    margin-left: 5px
                }

                .mfp-img-mobile .mfp-bottom-bar {
                    background: rgba(0,0,0,.6);
                    bottom: 0;
                    margin: 0;
                    top: auto;
                    padding: 3px 5px;
                    position: fixed;
                    box-sizing: border-box
                }

                .mfp-img-mobile .mfp-bottom-bar:empty {
                    padding: 0
                }

                .mfp-img-mobile .mfp-counter {
                    right: 5px;
                    top: 3px
                }

                .mfp-img-mobile .mfp-close {
                    top: 0;
                    right: 0;
                    width: 35px;
                    height: 35px;
                    line-height: 35px;
                    background: rgba(0,0,0,.6);
                    position: fixed;
                    text-align: center;
                    padding: 0
                }
            }

            @media (max-width: 900px) {
                .mfp-arrow {
                    -webkit-transform:scale(.75);
                    transform: scale(.75)
                }

                .mfp-arrow-left {
                    -webkit-transform-origin: 0;
                    transform-origin: 0
                }

                .mfp-arrow-right {
                    -webkit-transform-origin: 100%;
                    transform-origin: 100%
                }

                .mfp-container {
                    padding-left: 6px;
                    padding-right: 6px
                }
            }

            .tatsu-accordion-inner {
                opacity: 0;
                transition: opacity .3s
            }

            .tatsu-accordion .accordion-head.ui-accordion-header {
                display: flex;
                transition: color .3s;
                align-items: center;
                cursor: pointer
            }

            .tatsu-accordion .tatsu-accordion-expand {
                height: 30px;
                width: 30px;
                margin: auto 0 auto auto;
                position: relative;
                display: inline-block
            }

            .tatsu-accordion-expand:after {
                height: 2px;
                width: 12px;
                margin-top: -1px;
                margin-left: -6px
            }

            .tatsu-accordion-expand:after,.tatsu-accordion-expand:before {
                position: absolute;
                top: 50%;
                content: "";
                display: block;
                background: currentColor;
                left: 50%
            }

            .tatsu-accordion-expand:before {
                height: 12px;
                width: 2px;
                margin-top: -6px;
                transition: opacity .25s,transform .25s;
                margin-left: -1px
            }

            .ui-accordion-header-active .tatsu-accordion-expand:before {
                transform: rotate(-90deg);
                opacity: 0
            }

            .accordion-content-inner>p:last-child {
                margin: 0
            }

            .accordion-with-bg {
                padding: 20px
            }

            .tatsu-accordion-style1 .accordion-head {
                padding: 15px 25px;
                border-radius: 3px 3px 0 0;
                border-width: 1px 1px 0;
                border-style: solid;
                margin: 15px 0 0;
                outline: none
            }

            .tatsu-accordion-style1 .accordion-head:first-child {
                margin-top: 0
            }

            .tatsu-accordion-style1 .accordion-content {
                padding: 0 25px 15px;
                box-shadow: 0 4px 6px rgba(0,0,0,.1);
                border-style: solid;
                border-width: 1px;
                border-top: 0;
                border-bottom-left-radius: 3px;
                border-bottom-right-radius: 3px
            }

            .tatsu-accordion-style1 .ui-corner-top.ui-accordion-header-collapsed {
                border-bottom-style: solid;
                border-bottom-width: 1px;
                border-bottom-left-radius: 3px;
                border-bottom-right-radius: 3px
            }

            .tatsu-accordion-style2 .accordion-head.ui-accordion-header {
                padding: 20px;
                outline: none;
                margin: 0;
                border-bottom: 1px solid
            }

            .tatsu-accordion-style2 .ui-accordion-header-active,.tatsu-accordion-style2 .ui-corner-top.ui-state-default {
                border: 0
            }

            .tatsu-accordion-style2 .accordion-content.ui-accordion-content {
                padding: 0 20px 20px
            }

            .tatsu-accordion-style2 .ui-accordion-content-active {
                border-bottom: 1px solid transparent
            }

            .tatsu-accordion .ui-accordion-header:before {
                content: none
            }

            @media only screen and (max-width: 1377px) {
            }

            @media only screen and (min-width: 768px) and (max-width: 1024px) {
            }

            @media only screen and (max-width: 767px) {
            }

            .A {
                font-family: "HK Grotesk",sans-serif;
            }

            .B {
                letter-spacing: 1px;
                text-transform: uppercase;
                font-family: "Inter",sans-serif;
            }

            .C {
                font-weight: 700;
            }

            .D {
                font-weight: 600;
            }

            .E {
                line-height: 1.25em;
            }

            .F {
                line-height: 1.5em;
            }

            .G {
                text-transform: none;
                letter-spacing: 0px;
            }

            .H {
                color: #182433;
            }

            .I {
                color: rgba(0,0,0,0.6);
            }

            .J {
                font-size: 55px;
            }

            .K {
                font-size: 40px;
            }

            .L {
                font-size: 30px;
            }

            .M {
                font-family: "Hans Kendrick",sans-serif;
                font-size: 34px;
            }

            .N {
                font-size: 26px;
            }

            .O {
                font-size: 22px;
            }

            .P {
                font-size: 20px;
            }

            .Q {
                font-size: 13px;
                line-height: 1.2em;
            }

            .R {
                font-weight: 500;
                font-size: 18px;
            }

            .S {
                font-size: 14px;
                line-height: 1em;
                color: #ffffff;
            }

            .bB {
                border-radius: 0px 0px 0px 0px;
            }

            .BB {
                height: 1px;
            }

            .CC {
                line-height: 36px;
                font-size: 24px;
            }

            .aB {
                border-radius: 12px;
            }

            .AB {
                width: 33.33%;
            }

            .BC {
                margin-bottom: 0px;
            }

            .a {
                background-position: top left;
                background-size: cover;
            }

            .AC {
                margin: 0 0 2px 0;
            }

            .b {
                border-color: rgba(233,243,255,1);
            }

            .c {
                border-color: rgba(155,155,155,0.2);
            }

            .d {
                font-family: "Open Sans";
            }

            .e {
                font-family: "Poppins";
            }

            .f {
                background-repeat: no-repeat;
                background-attachment: scroll;
            }

            .g {
                box-shadow: 0px 0px 0px 0px rgba(0,0,0,0);
            }

            .h {
                fill: #ffffff;
            }

            .zB {
                font-size: 16px;
            }

            .ZB {
                border-radius: 30px 30px 30px 30px;
            }

            .i {
                color: rgba(0,0,0,1);
            }

            .yB {
                margin: -2px 0px 0px 0px;
            }

            .YB {
                padding: 1px;
            }

            .j {
                color: #ffffff;
            }

            .xB {
                background-color: rgba(236,230,211,1);
            }

            .XB {
                padding: 10px 0px 0px 0px;
            }

            .k {
                color: rgba(42,188,138,1);
            }

            .wB {
                background-color: rgba(252,251,248,1);
            }

            .WB {
                padding: 60px 0px 30px 0px;
            }

            .l {
                color: rgba(56,100,223,1);
            }

            .vB {
                padding: 50px 0px 50px 0px;
            }

            .VB {
                padding: 50px 50px 50px 50px;
            }

            .m {
                color: #182433;
            }

            .uB {
                width: 46%;
            }

            .UB {
                padding: 90px 0px 90px 0px;
            }

            .n {
                color: #22BF8E;
            }

            .tB {
                box-shadow: 0px 30px 60px 0px rgba(0,0,0,0.05);
            }

            .TB {
                padding: 25px 25px 25px 25px;
            }

            .o {
                color: #F5C74D;
            }

            .sB {
                padding: 5px 5px 5px 5px;
            }

            .SB {
                padding: 30px 0px 30px 0px;
            }

            .TC {
                width: 60%;
            }

            .p {
                color: rgba(65,117,5,1);
            }

            .rB {
                margin-bottom: 10px;
            }

            .RB {
                padding: 0px 0px 0px 0px;
            }

            .SC {
                margin-top: 60px;
            }

            .q {
                color: #1b86f1;
            }

            .qB {
                width: 40%;
            }

            .QB {
                mix-blend-mode: normal;
            }

            .RC {
                padding-bottom: 120%;
            }

            .r {
                background-color: rgba(248,245,237,1);
            }

            .pB {
                background-color: rgba(16,38,101,1);
            }

            .PB {
                margin: 0px 0px 15px 0px;
            }

            .QC {
                padding: 7% 10% 7% 35%;
            }

            .s {
                background-color: rgba(255,255,255,1);
            }

            .oB {
                margin: 0px 0px 0px -15%;
            }

            .OB {
                margin: 0px 0px 25px 0px;
            }

            .PC {
                width: 864px;
            }

            .t {
                border-style: solid;
                border-image: none;
                border-width: 2px 2px 2px 2px;
            }

            .nB {
                width: 1920px;
            }

            .NB {
                margin: 0px 0px 14px 0px;
            }

            .OC {
                width: 64.24%;
            }

            .u {
                text-align: left;
            }

            .mB {
                background-image: url(https://media.swipepages.com/2020/2/contact-bg.svg);
            }

            .MB {
                margin: 0px 0px 10px 0px;
            }

            .NC {
                line-height: 42px;
                font-weight: 600;
                font-size: 36px;
            }

            .v {
                text-align: center;
            }

            .lB {
                padding-bottom: 68.51851851851852%;
            }

            .LB {
                margin: 0px 0px 20px 0px;
            }

            .MC {
                font-family: "Montserrat";
                margin-bottom: 8px;
                font-size: 20px;
            }

            .w {
                height: 4px;
                background: rgba(42,188,138,1);
                width: 50px;
            }

            .kB {
                padding-bottom: 157.8%;
            }

            .KB {
                margin: 0px 0px 30px 0px;
            }

            .LC {
                width: 54%;
            }

            .x {
                width: 50%;
            }

            .jB {
                width: 900px;
            }

            .JB {
                margin: 0px 0px 40px 0px;
            }

            .KC {
                width: 1080px;
            }

            .Y {
                font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen-Sans,Ubuntu,Cantarell,'Helvetica Neue',sans-serif;
                letter-spacing: 0;
                font-weight: 400;
                line-height: 1.3em;
            }

            .y {
                width: 100;
            }

            .iB {
                font-size: 12px;
            }

            .IB {
                margin: 0px 0px 50px 0px;
            }

            .JC {
                padding-bottom: 56.25%;
            }

            .Z {
                background-position: center center;
                background-size: initial;
            }

            .z {
                width: 100%;
            }

            .hB {
                max-width: none;
            }

            .HB {
                margin: 0px 0px 0px 0px;
            }

            .IC {
                margin-bottom: 90px;
            }

            .gB {
                max-width: 100%;
            }

            .GB {
                background: rgba(56,100,223,0.1);
            }

            .HC {
                width: 65%;
            }

            .fB {
                background-image: url(https://media.swipepages.com/2020/2/numbers-bg-1.svg);
            }

            .FB {
                background: #efefef;
            }

            .GC {
                padding: 2px 0px 0px 0px;
            }

            .eB {
                font-weight: 700;
            }

            .EB {
                transform: translate3d(0px,0px, 0);
            }

            .FC {
                padding: 20px 0px 20px 0px;
            }

            .dB {
                margin-top: 0px;
            }

            .DB {
                text-transform: none;
            }

            .EC {
                font-size: 30px;
            }

            .cB {
                border-radius: 5px;
            }

            .CB {
                padding-bottom: 100%;
            }

            .DC {
                font-weight: 800;
                font-size: 50px;
            }

            .UC:after {
                border-image: none;
                border-color: rgba(42,188,138,1);
                border-width: 1px;
            }

            .VC:after {
                color: rgba(42,188,138,1);
            }

            .WC:before {
                border-width: 1px;
                border-image: none;
                border-color: rgba(42,188,138,1);
                background: rgba(94,163,20,1);
            }

            @media only screen and (max-width: 1377px) {
                .XC {
                    transform:translate3d(0px,0px, 0);
                }

                .YC {
                    padding: 0px 0px 0px 0px;
                }

                .ZC {
                    padding: 7% 10% 7% 15%;
                }

                .aC {
                    padding-bottom: 120%;
                }

                .bC {
                    width: 900px;
                    max-width: 100%;
                }
            }

            @media only screen and (min-width: 768px) and (max-width: 1024px) {
                .T {
                    font-size:42px;
                }

                .U {
                    font-size: 26px;
                }

                .cC {
                    margin: 0px 0px 45px 0px;
                }

                .pC {
                    padding-bottom: 120%;
                }

                .oC {
                    width: 129.445%;
                }

                .nC {
                    width: 900px;
                    max-width: 100%;
                }

                .mC {
                    width: 142.075%;
                }

                .lC {
                    padding: 7% 20px 7% 20px;
                }

                .kC {
                    padding: 120px 0px 0px 0px;
                }

                .jC {
                    max-width: none;
                }

                .iC {
                    width: 80%;
                }

                .hC {
                    width: 50%;
                }

                .gC {
                    width: 100%;
                }

                .fC {
                    padding: 50px 20px 50px 20px;
                }

                .eC {
                    padding: 0px 0px 0px 0px;
                }

                .dC {
                    transform: translate3d(0px,0px, 0);
                }
            }

            @media only screen and (max-width: 767px) {
                .V {
                    font-size:36px;
                }

                .W {
                    font-size: 30px;
                }

                .X {
                    font-size: 26px;
                }

                .DD {
                    font-weight: 700;
                    font-size: 36px;
                }

                .CD {
                    margin: 0px 0px 0px 0px;
                }

                .BD {
                    width: 1080px;
                }

                .AD {
                    margin: 0px 0px 0px 0%;
                }

                .zC {
                    text-align: center;
                }

                .yC {
                    padding-bottom: 120%;
                }

                .xC {
                    max-width: 100%;
                }

                .wC {
                    padding: 50px 20px 50px 20px;
                }

                .vC {
                    padding: 45px 0px 90px 0px;
                }

                .uC {
                    padding: 0px 0px 0px 0px;
                }

                .tC {
                    margin: 10px 0px 20px 0px;
                }

                .sC {
                    transform: translate3d(0px,0px, 0);
                }

                .rC {
                    margin-bottom: 0px;
                }

                .qC {
                    width: 100%;
                }

                .GD {
                    width: 900px;
                }

                .FD {
                    margin-top: 10px;
                }

                .ED {
                    margin: 0px 0px 20px 0px;
                }
            }

            @font-face {
                font-family: 'HK Grotesk';
                src: url('https://assets.swipepages.com/fonts/hkgrotesk/medium/HKGrotesk-Medium.woff') format('woff'),url('https://assets.swipepages.com/fonts/hkgrotesk/medium/HKGrotesk-Medium.eot?#iefix') format('embedded-opentype'), url('https://assets.swipepages.com/fonts/hkgrotesk/medium/HKGrotesk-Medium.otf') format('opentype'), url('https://assets.swipepages.com/fonts/hkgrotesk/medium/HKGrotesk-Medium.ttf') format('truetype'), url('https://assets.swipepages.com/fonts/hkgrotesk/medium/HKGrotesk-Medium.svg#HKGrotesk-Medium') format('svg');
                font-weight: 500;
                font-style: normal;
                font-display: swap;
            }

            @font-face {
                font-family: 'HK Grotesk';
                src: url('https://assets.swipepages.com/fonts/hkgrotesk/bold/HKGrotesk-Bold.woff') format('woff'), url('https://assets.swipepages.com/fonts/hkgrotesk/bold/HKGrotesk-Bold.eot?#iefix') format('embedded-opentype'), url('https://assets.swipepages.com/fonts/hkgrotesk/bold/HKGrotesk-Bold.otf') format('opentype'), url('https://assets.swipepages.com/fonts/hkgrotesk/bold/HKGrotesk-Bold.ttf') format('truetype'), url('https://assets.swipepages.com/fonts/hkgrotesk/bold/HKGrotesk-Bold.svg#HKGrotesk-Bold') format('svg');
                font-weight: 700;
                font-style: normal;
                font-display: swap;
            }

            @font-face {
                font-family: 'HK Grotesk';
                src: url('https://assets.swipepages.com/fonts/hkgrotesk/semibold/HKGrotesk-SemiBold.woff') format('woff'), url('https://assets.swipepages.com/fonts/hkgrotesk/semibold/HKGrotesk-SemiBold.eot?#iefix') format('embedded-opentype'), url('https://assets.swipepages.com/fonts/hkgrotesk/semibold/HKGrotesk-SemiBold.otf') format('opentype'), url('https://assets.swipepages.com/fonts/hkgrotesk/semibold/HKGrotesk-SemiBold.ttf') format('truetype'), url('https://assets.swipepages.com/fonts/hkgrotesk/semibold/HKGrotesk-SemiBold.svg#HKGrotesk-SemiBold') format('svg');
                font-weight: 600;
                font-style: normal;
                font-display: swap;
            }

            @font-face {
                font-family: 'Inter';
                src: url('https://assets.swipepages.com/fonts/inter/semibold/Inter-SemiBold.woff') format('woff'), url('https://assets.swipepages.com/fonts/inter/semibold/Inter-SemiBold.eot?#iefix') format('embedded-opentype'), url('https://assets.swipepages.com/fonts/inter/semibold/Inter-SemiBold.otf') format('opentype'), url('https://assets.swipepages.com/fonts/inter/semibold/Inter-SemiBold.ttf') format('truetype'), url('https://assets.swipepages.com/fonts/inter/semibold/Inter-SemiBold.svg#Inter-SemiBold') format('svg');
                font-weight: 600;
                font-style: normal;
                font-display: swap;
            }

            @font-face {
                font-family: 'Hans Kendrick';
                src: url('https://assets.swipepages.com/fonts/hanskendrick/bold/HansKendrick-Bold.woff2') format('woff2'), url('https://assets.swipepages.com/fonts/hanskendrick/bold/HansKendrick-Bold.woff') format('woff'), url('https://assets.swipepages.com/fonts/hanskendrick/bold/HansKendrick-Bold.eot?#iefix') format('embedded-opentype'), url('https://assets.swipepages.com/fonts/hanskendrick/bold/HansKendrick-Bold.ttf') format('truetype'), url('https://assets.swipepages.com/fonts/hanskendrick/bold/HansKendrick-Bold.svg#HansKendrick-Bold') format('svg');
                font-weight: 700;
                font-style: normal;
                font-display: swap;
            }
			.bt{
				background-color: red;
				margin-right: 80px;
				color: white;
				
			}
        </style>
    </head>
    <body class="A F G I R">
        <!--sp-tracking-page-bodyOpen-->
        <!-- Google tag (gtag.js) -->
        <amp-analytics type="gtag" data-credentials="include">
            <script type="application/json">
                {
                    "vars": {
                        "gtag_id": "AW-11141316843",
                        "config": {
                            "AW-11141316843": {
                                "groups": "default"
                            }}
                        },
                        "triggers": {
                        }
                    }</script>
            </amp-analytics>
            <!--/sp-tracking-page-bodyOpen-->
            <div class="tatsu-header lE">
                <div class="jE">
                    <div class="kE PD">
                        <div class="oE">
                            <img alt="logo" src="https://media.swipepages.com/2021/7/aswini-homeoe-ayurvedic-products-limited-logo.png">
                        </div>
                        <div class="tatsu-header-menu"></div>
                        <div class="nE mE">
                            <a target="_blank" class="uD pD typo-button B D S" href="https://aswinishop.com/hi/cart/44057516933320:1">&#x905;&#x92D;&#x940;&#x916;&#x930;&#x940;&#x926;&#x947;&#x902;</a>
                        </div>
                    </div>
                </div>
                <div class="tatsu-mobile-menu" [class]="isOpen ? &apos;tatsu-mobile-menu open&apos; : &apos;tatsu-mobile-menu&apos;"></div>
            </div>
            <div class="tatsu-0WcoCKMZhpF ID lD tatsu-section-offset s">
                <div class="LD lD RB kC">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-KUjgGIGB8Vs TD PD RD VD">
                                <div class="OD kD z">
                                    <div class="QD GC">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-XipDJUsj5MK bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-P9U5LPer0lZ h1 eE tatsu-title-wrap-h1 v HB XB tC">
                                                            <h1 class="tatsu-title hE A C E G H J e p s z DB DC T V DD">
                                                                <span style="color: #d0021b;">&#x926;&#x930;&#x94D;&#x926;</span>
                                                                &#x91C;&#x93E;&#x926;&#x942;&#x915;&#x940;&#x924;&#x930;&#x939;&#x92A;&#x93F;&#x918;&#x932;&#x91C;&#x93E;&#x924;&#x93E;&#x939;&#x948;!
                                                            </h1>
                                                        </div>
                                                        <div class="tatsu-module tatsu-o1k09fuFJSN h1 eE tatsu-title-wrap-h1 v MB XB tC">
                                                            <h1 class="tatsu-title hE A C E G H J e i s z DB NC T V">
                                                                <span style="color: #417505;">3 &#x92E;&#x93F;&#x928;&#x91F;&#x92E;&#x947;&#x902;</span>
                                                                &#x918;&#x941;&#x91F;&#x928;&#x947;, &#x92A;&#x940;&#x920;&#x92F;&#x93E;&#x92E;&#x93F;&#x928;&#x91F;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x91B;&#x941;&#x91F;&#x915;&#x93E;&#x930;&#x93E;&#x92A;&#x93E;&#x90F;&#x902;!
                                                            </h1>
                                                        </div>
                                                        <div class="tatsu-module tatsu-O4eaab4NVy2V tatsu-module mD KB ED">
                                                            <div class="hD tatsu-align-left HD v z CC">
                                                                <p>
                                                                    <span style="color: #000000;">
                                                                        <strong>&#x906;&#x92A;&#x915;&#x94B;&#x939;&#x93F;&#x930;&#x928;&#x92A;&#x930;&#x92D;&#x930;&#x94B;&#x938;&#x93E;&#x915;&#x94D;&#x92F;&#x94B;&#x902;&#x915;&#x930;&#x928;&#x93E;&#x91A;&#x93E;&#x939;&#x93F;&#x90F;? &#x939;&#x91C;&#x93E;&#x930;&#x94B;&#x902;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x94D;&#x924;&#x93E;&#x913;&#x902;&#x938;&#x947;&#x91C;&#x941;&#x921;&#x93C;&#x947;&#x902;&#x914;&#x930;&#x91C;&#x93E;&#x928;&#x947;&#x902;&#x915;&#x93F;&#x909;&#x928;&#x94D;&#x939;&#x947;&#x902;&#x915;&#x94D;&#x92F;&#x93E;&#x915;&#x939;&#x928;&#x93E;&#x939;&#x948;!</strong>
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module pE tatsu-hosted-wrap tatsu-hosted-wrap tatsu-EXs4dfpjs65C">
                                                            <a style="padding-top:56.25%;" class="mfp-inline poster-video poster-video-EXs4dfpjs65C be-video-embed tatsu-video-wrapper tatsu-video-placeholder" href="#video-EXs4dfpjs65C" data-loop=" 0" data-autoplay="0" data-aspect-ratio="16:9">
                                                                <svg class="dE" width="74" height="74" viewBox="0 0 74 74" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <circle cx="37" cy="37" r="36.5" fill="white" stroke="white"/>
                                                                    <path d="M53.9333 35.2679C55.2667 36.0377 55.2667 37.9622 53.9333 38.732L30.0334 52.5307C28.7 53.3005 27.0334 52.3383 27.0334 50.7987L27.0334 23.2013C27.0334 21.6617 28.7 20.6995 30.0334 21.4693L53.9333 35.2679Z" fill="black"/>
                                                                </svg>
                                                                <img class="cE" src="https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi---hiran-video-testimonials---169--1--1500.webp">
                                                            </a>
                                                            <div id="video-EXs4dfpjs65C" class="mfp-hide white-popup tatsu-video-wrapper">
                                                                <video controls data-src="https://aswini.s3.ap-south-1.amazonaws.com/Hindi_Hiran_Video_Testimonials.mp4" preload="metadata" width="100%" controlslist="nodownload" playsinline>
                                                                    <source src="https://aswini.s3.ap-south-1.amazonaws.com/Hindi_Hiran_Video_Testimonials.mp4" type="video/mp4">
                                                                </video>
                                                            </div>
                                                        </div>
                                                        <div class="aD be-preview lD tatsu-C5xAQT0aRe12 SD RD tatsu-inner-row-wrap dB">
                                                            <div class="OD kD rB rC">
                                                                <div class="QD">
                                                                    <div class="WD lD tatsu-column-no-bg ZD tatsu-5xIjYYK0awS9 dD x AC XC dC qC sC">
                                                                        <div class="tatsu-column-inner gradientClass g">
                                                                            <div class="XD">
                                                                                <div class="gD YC eC uC">
                                                                                    <div class="tatsu-VFhPuJkyc2XN PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE PB">
                                                                                        <div class="zD">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="l">
                                                                                                <path d="M 16 3 C 8.800781 3 3 8.800781 3 16 C 3 23.199219 8.800781 29 16 29 C 23.199219 29 29 23.199219 29 16 C 29 14.601563 28.8125 13.207031 28.3125 11.90625 L 26.6875 13.5 C 26.886719 14.300781 27 15.101563 27 16 C 27 22.101563 22.101563 27 16 27 C 9.898438 27 5 22.101563 5 16 C 5 9.898438 9.898438 5 16 5 C 19 5 21.695313 6.195313 23.59375 8.09375 L 25 6.6875 C 22.699219 4.386719 19.5 3 16 3 Z M 27.28125 7.28125 L 16 18.5625 L 11.71875 14.28125 L 10.28125 15.71875 L 15.28125 20.71875 L 16 21.40625 L 16.71875 20.71875 L 28.71875 8.71875 Z"/>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <div class="XE">
                                                                                            <div class="WE typo-h6 A D F G H P m">
                                                                                                <a>&#x924;&#x924;&#x94D;&#x915;&#x93E;&#x932;&#x930;&#x93E;&#x939;&#x924;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x924;&#x947;&#x91C;&#x940;&#x938;&#x947;&#x915;&#x93E;&#x92E;&#x915;&#x930;&#x928;&#x947;&#x935;&#x93E;&#x932;&#x93E;&#x92B;&#x949;&#x930;&#x94D;&#x92E;&#x942;&#x932;&#x93E;</a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="tatsu-0YIiLuqpqnw5 PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE PB">
                                                                                        <div class="zD">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="l">
                                                                                                <path d="M 16 3 C 8.800781 3 3 8.800781 3 16 C 3 23.199219 8.800781 29 16 29 C 23.199219 29 29 23.199219 29 16 C 29 14.601563 28.8125 13.207031 28.3125 11.90625 L 26.6875 13.5 C 26.886719 14.300781 27 15.101563 27 16 C 27 22.101563 22.101563 27 16 27 C 9.898438 27 5 22.101563 5 16 C 5 9.898438 9.898438 5 16 5 C 19 5 21.695313 6.195313 23.59375 8.09375 L 25 6.6875 C 22.699219 4.386719 19.5 3 16 3 Z M 27.28125 7.28125 L 16 18.5625 L 11.71875 14.28125 L 10.28125 15.71875 L 15.28125 20.71875 L 16 21.40625 L 16.71875 20.71875 L 28.71875 8.71875 Z"/>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <div class="XE">
                                                                                            <div class="WE typo-h6 A D F G H P m">
                                                                                                <a>&#x915;&#x94B;&#x908;&#x924;&#x948;&#x932;&#x940;&#x92F;&#x905;&#x935;&#x936;&#x947;&#x937;&#x91B;&#x94B;&#x921;&#x93C;&#x947;&#x92C;&#x93F;&#x928;&#x93E;&#x91A;&#x93F;&#x915;&#x928;&#x93E;&#x908;&#x930;&#x939;&#x93F;&#x924;</a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="tatsu-4q_bT14szXsg PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE PB">
                                                                                        <div class="zD">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="l">
                                                                                                <path d="M 16 3 C 8.800781 3 3 8.800781 3 16 C 3 23.199219 8.800781 29 16 29 C 23.199219 29 29 23.199219 29 16 C 29 14.601563 28.8125 13.207031 28.3125 11.90625 L 26.6875 13.5 C 26.886719 14.300781 27 15.101563 27 16 C 27 22.101563 22.101563 27 16 27 C 9.898438 27 5 22.101563 5 16 C 5 9.898438 9.898438 5 16 5 C 19 5 21.695313 6.195313 23.59375 8.09375 L 25 6.6875 C 22.699219 4.386719 19.5 3 16 3 Z M 27.28125 7.28125 L 16 18.5625 L 11.71875 14.28125 L 10.28125 15.71875 L 15.28125 20.71875 L 16 21.40625 L 16.71875 20.71875 L 28.71875 8.71875 Z"/>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <div class="XE">
                                                                                            <div class="WE typo-h6 A D F G H P m">
                                                                                                <a>&#x938;&#x92D;&#x940;&#x909;&#x92E;&#x94D;&#x930;&#x915;&#x947;&#x932;&#x94B;&#x917;&#x94B;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x909;&#x92A;&#x92F;&#x941;&#x915;&#x94D;&#x924;, &#x92A;&#x930;&#x93F;&#x935;&#x93E;&#x930;&#x915;&#x947;&#x905;&#x928;&#x941;&#x915;&#x942;&#x932;&#x924;&#x947;&#x932;</a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="eD">
                                                                                <div class="fD"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="WD qE lD tatsu-column-no-bg ZD tatsu-HGnu__nh-cZj dD x XC dC qC sC CD">
                                                                        <div class="tatsu-column-inner gradientClass g">
                                                                            <div class="XD">
                                                                                <div class="gD YC eC uC">
                                                                                    <div class="tatsu-wARbhlAIBwBt PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE PB">
                                                                                        <div class="zD">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="l">
                                                                                                <path d="M 16 3 C 8.800781 3 3 8.800781 3 16 C 3 23.199219 8.800781 29 16 29 C 23.199219 29 29 23.199219 29 16 C 29 14.601563 28.8125 13.207031 28.3125 11.90625 L 26.6875 13.5 C 26.886719 14.300781 27 15.101563 27 16 C 27 22.101563 22.101563 27 16 27 C 9.898438 27 5 22.101563 5 16 C 5 9.898438 9.898438 5 16 5 C 19 5 21.695313 6.195313 23.59375 8.09375 L 25 6.6875 C 22.699219 4.386719 19.5 3 16 3 Z M 27.28125 7.28125 L 16 18.5625 L 11.71875 14.28125 L 10.28125 15.71875 L 15.28125 20.71875 L 16 21.40625 L 16.71875 20.71875 L 28.71875 8.71875 Z"/>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <div class="XE">
                                                                                            <div class="WE typo-h6 A D F G H P m">
                                                                                                <a>&#x939;&#x91C;&#x93E;&#x930;&#x94B;&#x902;&#x932;&#x94B;&#x917;&#x94B;&#x902;&#x928;&#x947;&#x907;&#x938;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x93F;&#x92F;&#x93E;&#x939;&#x948;</a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="tatsu-ESMUEkacROLj PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE PB">
                                                                                        <div class="zD">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="l">
                                                                                                <path d="M 16 3 C 8.800781 3 3 8.800781 3 16 C 3 23.199219 8.800781 29 16 29 C 23.199219 29 29 23.199219 29 16 C 29 14.601563 28.8125 13.207031 28.3125 11.90625 L 26.6875 13.5 C 26.886719 14.300781 27 15.101563 27 16 C 27 22.101563 22.101563 27 16 27 C 9.898438 27 5 22.101563 5 16 C 5 9.898438 9.898438 5 16 5 C 19 5 21.695313 6.195313 23.59375 8.09375 L 25 6.6875 C 22.699219 4.386719 19.5 3 16 3 Z M 27.28125 7.28125 L 16 18.5625 L 11.71875 14.28125 L 10.28125 15.71875 L 15.28125 20.71875 L 16 21.40625 L 16.71875 20.71875 L 28.71875 8.71875 Z"/>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <div class="XE">
                                                                                            <div class="WE typo-h6 m A D F G H P">
                                                                                                <a>&#x935;&#x93F;&#x936;&#x94D;&#x935;&#x938;&#x928;&#x940;&#x92F;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x91A;&#x93F;&#x915;&#x93F;&#x924;&#x94D;&#x938;&#x915;&#x940;&#x92F;&#x92A;&#x930;&#x940;&#x915;&#x94D;&#x937;&#x923;&#x915;&#x93F;&#x92F;&#x93E;&#x917;&#x92F;&#x93E;&#x964;</a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="tatsu-npmwA4Ml6ByI PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE PB">
                                                                                        <div class="zD">
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="l">
                                                                                                <path d="M 16 3 C 8.800781 3 3 8.800781 3 16 C 3 23.199219 8.800781 29 16 29 C 23.199219 29 29 23.199219 29 16 C 29 14.601563 28.8125 13.207031 28.3125 11.90625 L 26.6875 13.5 C 26.886719 14.300781 27 15.101563 27 16 C 27 22.101563 22.101563 27 16 27 C 9.898438 27 5 22.101563 5 16 C 5 9.898438 9.898438 5 16 5 C 19 5 21.695313 6.195313 23.59375 8.09375 L 25 6.6875 C 22.699219 4.386719 19.5 3 16 3 Z M 27.28125 7.28125 L 16 18.5625 L 11.71875 14.28125 L 10.28125 15.71875 L 15.28125 20.71875 L 16 21.40625 L 16.71875 20.71875 L 28.71875 8.71875 Z"/>
                                                                                            </svg>
                                                                                        </div>
                                                                                        <div class="XE">
                                                                                            <div class="WE typo-h6 m A D F G H P">
                                                                                                <a>&#x915;&#x94B;&#x92E;&#x932;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x915;&#x947;&#x932;&#x93F;&#x90F;100% &#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x938;&#x93E;&#x92E;&#x917;&#x94D;&#x930;&#x940;</a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="eD">
                                                                                <div class="fD"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-BM3dtKrDRDni ID lD tatsu-section-offset">
                <div class="LD lD SB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-xzFztx6IKMme TD PD RD VD FD">
                                <div class="OD kD z rC">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-7dR-ucCjQEMg bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-v0-aRBws5C6Q tatsu-module mD MB">
                                                            <div class="hD tatsu-align-left HD i v z">
                                                                <p>
                                                                    <strong>&#x915;&#x908;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x94D;&#x924;&#x93E;&#x913;&#x902;&#x926;&#x94D;&#x935;&#x93E;&#x930;&#x93E;5 &#x938;&#x94D;&#x91F;&#x93E;&#x930;&#x930;&#x947;&#x91F;&#x93F;&#x902;&#x917;&#x926;&#x940;&#x917;&#x908;</strong>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-NHRm1UsV5w_3 tatsu-module IE OE MB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 100%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-Hf65yUE_VKhQ tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD v z">
                                                                <p>
                                                                    <span style="color: #000000;">
                                                                        <strong>&#x1F69A;&#x92E;&#x941;&#x92B;&#x93C;&#x94D;&#x924;&#x939;&#x94B;&#x92E;&#x921;&#x93F;&#x932;&#x940;&#x935;&#x930;&#x940;| &#x1F4B0;&#x938;&#x940;&#x913;&#x921;&#x940;&#x909;&#x92A;&#x932;&#x92C;&#x94D;&#x927;&#x939;&#x948;| &#x1F381;&#x905;&#x92D;&#x940;&#x932;&#x947;&#x902;11% &#x915;&#x940;&#x91B;&#x942;&#x91F;!</strong>
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module oD tD tatsu-JEsvaQJCEEns qE none B D S v LB">
                                                            <div class="qD YB UC WC">
                                                                <a class="tatsu-shortcode pD wD bg-animation-none left-icon sub-text" data-append-query-params="true" href="https://aswinishop.com/hi/cart/44057516933320:1">
                                                                    <div>
                                                                        <span class="rD DB eB MC VC" data-text="&#x916;&#x930;&#x940;&#x926;&#x947;&#x902; &#x938;&#x93F;&#x930;&#x94D;&#x92B; 239/- &#x92E;&#x947;&#x902;">
                                                                            <span class="default j">&#x916;&#x930;&#x940;&#x926;&#x947;&#x902;&#x938;&#x93F;&#x930;&#x94D;&#x92B;239/- &#x92E;&#x947;&#x902;</span>
                                                                        </span>
                                                                        <span class="sD Y j DB zB VC" data-text="&#x90F;&#x915; &#x92C;&#x942;&#x902;&#x926;, &#x924;&#x941;&#x930;&#x902;&#x924; &#x930;&#x93E;&#x939;&#x924;">
                                                                            <span class="default">&#x90F;&#x915;&#x92C;&#x942;&#x902;&#x926;, &#x924;&#x941;&#x930;&#x902;&#x924;&#x930;&#x93E;&#x939;&#x924;</span>
                                                                        </span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-oJuywJBxj6jF ID lD tatsu-section-offset">
                <div class="LD lD WB vC">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-kS0Fwh7Jqe_T TD PD RD VD">
                                <div class="OD y gC qC">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-Bdc3Zg4zoLqB bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-IWZeVUUmcx-v h2 eE tatsu-title-wrap-h2 v">
                                                            <h2 class="tatsu-title hE A C E G H K z V">&#x939;&#x93F;&#x930;&#x928;&#x926;&#x930;&#x94D;&#x926;&#x928;&#x93F;&#x935;&#x93E;&#x930;&#x915;&#x924;&#x947;&#x932;&#x915;&#x94D;&#x92F;&#x94B;&#x902;&#x91A;&#x941;&#x928;&#x947;&#x902;?</h2>
                                                        </div>
                                                        <div class="tatsu-module tatsu-TIzyNaaAGb23 tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD u z zC">
                                                                <p>
                                                                    <span style="color: #000000;">
                                                                        <strong>&#x918;&#x941;&#x91F;&#x928;&#x947;, &#x92A;&#x940;&#x920;&#x914;&#x930;&#x905;&#x928;&#x94D;&#x92F;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;3 &#x92E;&#x93F;&#x928;&#x91F;&#x92E;&#x947;&#x902;&#x930;&#x93E;&#x939;&#x924;&#x92A;&#x93E;&#x928;&#x947;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x92A;&#x93E;&#x935;&#x930;-&#x92A;&#x948;&#x915;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x905;&#x935;&#x92F;&#x935;&#x94B;&#x902;&#x915;&#x93E;&#x90F;&#x915;&#x905;&#x928;&#x942;&#x920;&#x93E;&#x938;&#x902;&#x92F;&#x94B;&#x91C;&#x928;, &#x939;&#x93F;&#x930;&#x928;&#x915;&#x93E;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x930;&#x939;&#x938;&#x94D;&#x92F;&#x916;&#x94B;&#x91C;&#x947;&#x902;&#x964;</strong>
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="HE tatsu-module tatsu-HKeZe7IGWbcs qE iD tatsu-image-lazyload tatsu-HKeZe7IGWbcs EB">
                                                            <div class="tatsu-single-image-inner ZB gB nB jC mC">
                                                                <div class="tatsu-single-image-padding-wrap JC"></div>
                                                                <img data-srcset="https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi-landing-page-banner---169--2--150.webp 150w,https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi-landing-page-banner---169--2--300.webp 300w,https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi-landing-page-banner---169--2--500.webp 500w,https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi-landing-page-banner---169--2--750.webp 750w,https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi-landing-page-banner---169--2--1000.webp 1000w,https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi-landing-page-banner---169--2--1500.webp 1500w" sizes="(max-width: 767px) 100vw,(max-width: 1024px) 142.075vw,(max-width: 1377px) 1160px, 1160px" alt data-src="https://media.swipepages.com/2023/10/5ff6c1a81bb3e30010dc353a/hindi-landing-page-banner---169--2--1500.webp" data-extension=".jpg" data-webp="1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="aD be-preview lD tatsu-TfSdymRj_H0s TD PD RD">
                                <div class="OD kD y gC qC">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-MlxLalriZ5_S dD x XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-owNAfzY40bLk tatsu-module mD qE">
                                                            <div class="hD tatsu-align-left HD i u z">
                                                                <p>&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x906;&#x92A;&#x915;&#x93E;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x938;&#x93E;&#x925;&#x940;: &#x939;&#x93F;&#x930;&#x928;&#x91C;&#x94B;&#x921;&#x93C;&#x914;&#x930;&#x918;&#x941;&#x91F;&#x928;&#x947;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x924;&#x947;&#x932;&#x938;&#x93E;&#x935;&#x927;&#x93E;&#x928;&#x940;&#x92A;&#x942;&#x930;&#x94D;&#x935;&#x915;&#x91A;&#x941;&#x928;&#x940;&#x917;&#x908;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x91C;&#x921;&#x93C;&#x940;-&#x92C;&#x942;&#x91F;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x93E;&#x92E;&#x93F;&#x936;&#x94D;&#x930;&#x923;&#x939;&#x948;&#x91C;&#x94B;&#x905;&#x92A;&#x928;&#x947;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x917;&#x941;&#x923;&#x94B;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x91C;&#x93E;&#x928;&#x93E;&#x91C;&#x93E;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                <p>&#x92F;&#x939;&#x938;&#x94C;&#x92E;&#x94D;&#x92F;&#x932;&#x947;&#x915;&#x93F;&#x928;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x940;&#x924;&#x947;&#x932;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;, &#x918;&#x941;&#x91F;&#x928;&#x947;&#x915;&#x940;&#x92A;&#x930;&#x947;&#x936;&#x93E;&#x928;&#x940;, &#x915;&#x920;&#x94B;&#x930;&#x924;&#x93E;&#x914;&#x930;&#x938;&#x942;&#x91C;&#x928;&#x915;&#x93E;&#x907;&#x932;&#x93E;&#x91C;&#x915;&#x930;&#x928;&#x947;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x92A;&#x942;&#x930;&#x940;&#x924;&#x930;&#x939;&#x938;&#x947;&#x938;&#x902;&#x92F;&#x941;&#x915;&#x94D;&#x924;&#x939;&#x948;, &#x91C;&#x94B;&#x906;&#x92E;&#x924;&#x94C;&#x930;&#x92A;&#x930;&#x911;&#x938;&#x94D;&#x91F;&#x93F;&#x92F;&#x94B;&#x906;&#x930;&#x94D;&#x925;&#x930;&#x93E;&#x907;&#x91F;&#x93F;&#x938;, &#x930;&#x942;&#x92E;&#x947;&#x91F;&#x94B;&#x907;&#x921;&#x917;&#x920;&#x93F;&#x92F;&#x93E;&#x914;&#x930;&#x905;&#x928;&#x94D;&#x92F;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x938;&#x947;&#x938;&#x902;&#x92C;&#x902;&#x927;&#x93F;&#x924;&#x938;&#x92E;&#x938;&#x94D;&#x92F;&#x93E;&#x913;&#x902;&#x938;&#x947;&#x91C;&#x941;&#x921;&#x93C;&#x93E;&#x939;&#x94B;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                <p>&#x92F;&#x939;&#x938;&#x94C;&#x92E;&#x94D;&#x92F;&#x932;&#x947;&#x915;&#x93F;&#x928;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x940;&#x924;&#x947;&#x932;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;, &#x918;&#x941;&#x91F;&#x928;&#x947;&#x915;&#x940;&#x92A;&#x930;&#x947;&#x936;&#x93E;&#x928;&#x940;, &#x915;&#x920;&#x94B;&#x930;&#x924;&#x93E;&#x914;&#x930;&#x938;&#x942;&#x91C;&#x928;&#x915;&#x93E;&#x907;&#x932;&#x93E;&#x91C;&#x915;&#x930;&#x928;&#x947;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x92A;&#x942;&#x930;&#x940;&#x924;&#x930;&#x939;&#x938;&#x947;&#x938;&#x902;&#x92F;&#x941;&#x915;&#x94D;&#x924;&#x939;&#x948;, &#x91C;&#x94B;&#x906;&#x92E;&#x924;&#x94C;&#x930;&#x92A;&#x930;&#x911;&#x938;&#x94D;&#x91F;&#x93F;&#x92F;&#x94B;&#x906;&#x930;&#x94D;&#x925;&#x930;&#x93E;&#x907;&#x91F;&#x93F;&#x938;, &#x930;&#x942;&#x92E;&#x947;&#x91F;&#x94B;&#x907;&#x921;&#x917;&#x920;&#x93F;&#x92F;&#x93E;&#x914;&#x930;&#x905;&#x928;&#x94D;&#x92F;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x938;&#x947;&#x938;&#x902;&#x92C;&#x902;&#x927;&#x93F;&#x924;&#x938;&#x92E;&#x938;&#x94D;&#x92F;&#x93E;&#x913;&#x902;&#x938;&#x947;&#x91C;&#x941;&#x921;&#x93C;&#x93E;&#x939;&#x94B;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-yFsCDqZ8H42L dD x XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-9YdKm_-dDYq8 PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x92E;&#x947;&#x902;&#x91C;&#x932;&#x928;&#x914;&#x930;&#x938;&#x942;&#x91C;&#x928;&#x915;&#x94B;&#x924;&#x941;&#x930;&#x902;&#x924;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-Q3PHS-Ta7548 PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE GB g">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x918;&#x941;&#x91F;&#x928;&#x94B;&#x902;&#x914;&#x930;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x92E;&#x947;&#x902;&#x926;&#x930;&#x94D;&#x926;&#x914;&#x930;&#x92A;&#x930;&#x947;&#x936;&#x93E;&#x928;&#x940;&#x938;&#x947;&#x924;&#x941;&#x930;&#x902;&#x924;&#x906;&#x930;&#x93E;&#x92E;&#x92E;&#x93F;&#x932;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-VT0U_7X66U4t PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x93F;&#x924;&#x915;&#x94D;&#x937;&#x947;&#x924;&#x94D;&#x930;&#x94B;&#x902;&#x92E;&#x947;&#x902;&#x917;&#x924;&#x93F;&#x936;&#x940;&#x932;&#x924;&#x93E;&#x914;&#x930;&#x932;&#x91A;&#x940;&#x932;&#x947;&#x92A;&#x928;&#x92E;&#x947;&#x902;&#x909;&#x932;&#x94D;&#x932;&#x947;&#x916;&#x928;&#x940;&#x92F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x938;&#x941;&#x927;&#x93E;&#x930;&#x939;&#x94B;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-Ef3cpSVz4R5Z PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE GB g">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x915;&#x920;&#x94B;&#x930;&#x924;&#x93E;&#x915;&#x94B;&#x938;&#x94D;&#x92A;&#x937;&#x94D;&#x91F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;, &#x938;&#x902;&#x92F;&#x941;&#x915;&#x94D;&#x924;&#x915;&#x93E;&#x930;&#x94D;&#x92F;&#x92E;&#x947;&#x902;&#x938;&#x941;&#x927;&#x93E;&#x930;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-7JfT-HyDXJMC PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <!-- <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg> -->
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x936;&#x930;&#x940;&#x930;&#x915;&#x940;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x92E;&#x930;&#x92E;&#x94D;&#x92E;&#x924;&#x914;&#x930;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x92A;&#x941;&#x928;&#x930;&#x94D;&#x928;&#x93F;&#x930;&#x94D;&#x92E;&#x93E;&#x923;&#x92E;&#x947;&#x902;&#x938;&#x939;&#x93E;&#x92F;&#x924;&#x93E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-stDxrSiEnwoA PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x938;&#x902;&#x92F;&#x941;&#x915;&#x94D;&#x924;&#x938;&#x94D;&#x935;&#x93E;&#x938;&#x94D;&#x925;&#x94D;&#x92F;&#x914;&#x930;&#x915;&#x932;&#x94D;&#x92F;&#x93E;&#x923;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x90F;&#x915;&#x938;&#x902;&#x924;&#x941;&#x932;&#x93F;&#x924;&#x926;&#x943;&#x937;&#x94D;&#x91F;&#x93F;&#x915;&#x94B;&#x923;&#x915;&#x94B;&#x92A;&#x94D;&#x930;&#x94B;&#x924;&#x94D;&#x938;&#x93E;&#x939;&#x93F;&#x924;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-i7xHEbxeUORR PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE GB g">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x935;&#x93E;&#x938;&#x94D;&#x924;&#x935;&#x93F;&#x915;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x914;&#x930;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x938;&#x93E;&#x92E;&#x917;&#x94D;&#x930;&#x940;&#x938;&#x947;&#x92C;&#x928;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-Xu3F9c8nIXQB PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x92C;&#x93F;&#x928;&#x93E;&#x915;&#x93F;&#x938;&#x940;&#x92A;&#x94D;&#x930;&#x924;&#x93F;&#x915;&#x942;&#x932;&#x926;&#x941;&#x937;&#x94D;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x915;&#x947;, &#x938;&#x941;&#x930;&#x915;&#x94D;&#x937;&#x93F;&#x924;&#x914;&#x930;&#x938;&#x94C;&#x92E;&#x94D;&#x92F;&#x939;&#x94B;&#x928;&#x947;&#x915;&#x93E;&#x906;&#x936;&#x94D;&#x935;&#x93E;&#x938;&#x928;&#x926;&#x93F;&#x92F;&#x93E;&#x917;&#x92F;&#x93E;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-cQGmDnTrysUm PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x928;&#x93F;&#x92F;&#x92E;&#x93F;&#x924;&#x906;&#x935;&#x947;&#x926;&#x928;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x94D;&#x924;&#x93E;&#x915;&#x947;&#x905;&#x928;&#x941;&#x915;&#x942;&#x932;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-6PTtHAUmfvrE PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE qE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x938;&#x92C;&#x938;&#x947;&#x905;&#x91A;&#x94D;&#x91B;&#x940;&#x92C;&#x93E;&#x924;&#x92F;&#x939;&#x939;&#x948;&#x915;&#x93F;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x92A;&#x930;&#x947;&#x936;&#x93E;&#x928;&#x940;&#x915;&#x94B;&#x92A;&#x94D;&#x930;&#x92C;&#x902;&#x927;&#x93F;&#x924;&#x915;&#x930;&#x928;&#x947;&#x915;&#x93E;&#x938;&#x92E;&#x917;&#x94D;&#x930;&#x924;&#x930;&#x940;&#x915;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-uE8uBybj92zT ID lD tatsu-section-offset">
                <div class="LD lD WB vC">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-4l9L6DEEri-G TD PD RD">
                                <div class="OD y iC qC">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-_YqPPCCMH-lb dD x XC cC dC gC sC qC">
                                            <div class="tatsu-column-inner gradientClass c t aB">
                                                <div class="XD">
                                                    <div class="gD TB">
                                                        <div class="tatsu-vzSXIDzy80Hz PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE UE LB">
                                                            <div class="zD VE g GB">
                                                                <!--?xml version="1.0" encoding="utf-8"?-->
                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="l">
                                                                    <path d="M 7.5 3 C 4.462 3 2 5.462 2 8.5 C 2 12.671 6.91225 16.713234 8.28125 17.990234 C 9.85825 19.460234 12 21.349609 12 21.349609 C 12 21.349609 14.14175 19.460234 15.71875 17.990234 C 17.08775 16.713234 22 12.671 22 8.5 C 22 5.462 19.538 3 16.5 3 C 13.605 3 12 5.0898438 12 5.0898438 C 12 5.0898438 10.395 3 7.5 3 z M 7.5 5 C 9.327 5 10.386063 6.2755937 10.414062 6.3085938 L 12 8 L 13.585938 6.3085938 C 13.595937 6.2955938 14.673 5 16.5 5 C 17.100787 5 17.657824 5.1658244 18.152344 5.4335938 L 12 11.585938 L 8.7070312 8.2929688 L 7.2929688 9.7070312 L 12 14.414062 L 19.566406 6.8476562 C 19.834176 7.3421763 20 7.8992131 20 8.5 C 20 11.419 16.230547 14.826375 14.810547 16.109375 C 14.633547 16.269375 14.480469 16.408391 14.355469 16.525391 C 13.604469 17.225391 12.716 18.029875 12 18.671875 C 11.284 18.029875 10.394531 17.224391 9.6445312 16.525391 C 9.5185313 16.408391 9.3654531 16.268375 9.1894531 16.109375 C 7.7694531 14.826375 4 11.419 4 8.5 C 4 6.57 5.57 5 7.5 5 z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="WE typo-h5 A D F G H O">
                                                                    <a>&#x92E;&#x947;&#x928;&#x94D;&#x925;&#x949;&#x932;&#x915;&#x940;&#x936;&#x915;&#x94D;&#x924;&#x93F;</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-fPMn_oPFmhXN tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD i u z">
                                                                <p>&#x92E;&#x947;&#x928;&#x94D;&#x925;&#x949;&#x932;&#x906;&#x92A;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x94D;&#x92F;&#x93E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;? &#x905;&#x92A;&#x928;&#x940;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x936;&#x940;&#x924;&#x932;&#x924;&#x93E;, &#x926;&#x930;&#x94D;&#x926;&#x928;&#x93F;&#x935;&#x93E;&#x930;&#x915;&#x914;&#x930;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x915;&#x94D;&#x937;&#x92E;&#x924;&#x93E;&#x913;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x92E;&#x947;&#x902;&#x905;&#x928;&#x92E;&#x94B;&#x932;, &#x92E;&#x947;&#x928;&#x94D;&#x925;&#x949;&#x932;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x92A;&#x940;&#x921;&#x93C;&#x93F;&#x924;&#x932;&#x94B;&#x917;&#x94B;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x90F;&#x915;&#x935;&#x930;&#x926;&#x93E;&#x928;&#x939;&#x948;&#x964;&#x92F;&#x939;&#x93E;&#x902;&#x92C;&#x924;&#x93E;&#x92F;&#x93E;&#x917;&#x92F;&#x93E;&#x939;&#x948;&#x915;&#x93F;&#x92F;&#x939;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x924;&#x930;&#x940;&#x915;&#x947;&#x938;&#x947;&#x915;&#x948;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x92A;&#x939;&#x941;&#x902;&#x91A;&#x93E;&#x924;&#x93E;&#x939;&#x948;:</p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-fO0bqONiGjNf PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x924;&#x941;&#x930;&#x902;&#x924;&#x920;&#x902;&#x921;&#x915;&#x938;&#x930;;&#x938;&#x940;&#x92D;&#x940;&#x92A;&#x94D;&#x930;&#x915;&#x93E;&#x930;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x906;&#x926;&#x930;&#x94D;&#x936;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-nC0w_LiLQrY4 PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-0G12RkXeDVRS PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x90F;&#x915;&#x92D;&#x930;&#x94B;&#x938;&#x947;&#x92E;&#x902;&#x926;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x91A;&#x93F;&#x915;&#x93F;&#x924;&#x94D;&#x938;&#x93E;: &#x910;&#x938;&#x947;&#x92F;&#x941;&#x917;&#x92E;&#x947;&#x902;&#x91C;&#x939;&#x93E;&#x902;&#x938;&#x93F;&#x902;&#x925;&#x947;&#x91F;&#x93F;&#x915;&#x926;&#x930;&#x94D;&#x926;&#x928;&#x93F;&#x935;&#x93E;&#x930;&#x915;&#x926;&#x935;&#x93E;&#x913;&#x902;&#x915;&#x93E;&#x92C;&#x94B;&#x932;&#x92C;&#x93E;&#x932;&#x93E;&#x939;&#x948;, &#x92E;&#x947;&#x928;&#x94D;&#x925;&#x949;&#x932;&#x90F;&#x915;&#x935;&#x93F;&#x936;&#x94D;&#x935;&#x938;&#x928;&#x940;&#x92F;&#x914;&#x930;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x926;&#x930;&#x94D;&#x926;&#x92A;&#x94D;&#x930;&#x92C;&#x902;&#x927;&#x928;&#x938;&#x92E;&#x93E;&#x927;&#x93E;&#x928;&#x915;&#x947;&#x930;&#x942;&#x92A;&#x92E;&#x947;&#x902;&#x938;&#x93E;&#x92E;&#x928;&#x947;&#x906;&#x924;&#x93E;&#x939;&#x948;, &#x91C;&#x94B;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x926;&#x935;&#x93E;&#x913;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x92A;&#x93E;&#x930;&#x902;&#x92A;&#x930;&#x93F;&#x915;&#x92D;&#x93E;&#x930;&#x924;&#x940;&#x92F;&#x92A;&#x94D;&#x930;&#x93E;&#x925;&#x92E;&#x93F;&#x915;&#x924;&#x93E;&#x913;&#x902;&#x915;&#x947;&#x905;&#x928;&#x941;&#x930;&#x942;&#x92A;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-2QBL7yW3_hdF PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x936;&#x930;&#x940;&#x930;&#x915;&#x940;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x91A;&#x93F;&#x915;&#x93F;&#x924;&#x94D;&#x938;&#x93E;&#x92E;&#x947;&#x902;&#x92E;&#x926;&#x926;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;: &#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x938;&#x93F;&#x926;&#x94D;&#x927;&#x93E;&#x902;&#x924;&#x94B;&#x902;&#x915;&#x947;&#x905;&#x928;&#x941;&#x938;&#x93E;&#x930;, &#x92E;&#x947;&#x928;&#x94D;&#x925;&#x949;&#x932;&#x938;&#x93F;&#x930;&#x94D;&#x92B;&#x932;&#x915;&#x94D;&#x937;&#x923;&#x94B;&#x902;&#x915;&#x94B;&#x915;&#x935;&#x930;&#x928;&#x939;&#x940;&#x902;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;&#x964;&#x92F;&#x939;&#x936;&#x930;&#x940;&#x930;&#x915;&#x940;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x92A;&#x94D;&#x930;&#x915;&#x94D;&#x930;&#x93F;&#x92F;&#x93E;&#x913;&#x902;&#x915;&#x947;&#x938;&#x93E;&#x925;&#x915;&#x93E;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;, &#x91C;&#x93F;&#x938;&#x938;&#x947;&#x938;&#x92E;&#x917;&#x94D;&#x930;&#x938;&#x902;&#x92F;&#x941;&#x915;&#x94D;&#x924;&#x938;&#x94D;&#x935;&#x93E;&#x938;&#x94D;&#x925;&#x94D;&#x92F;&#x914;&#x930;&#x916;&#x941;&#x936;&#x939;&#x93E;&#x932;&#x940;&#x92E;&#x947;&#x902;&#x938;&#x941;&#x927;&#x93E;&#x930;&#x939;&#x94B;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-I1V3tnO2z8De tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB">
                                                        </div>
                                                        <div class="tatsu-module oD tatsu-9a0ougoEWezf qE none B D S u">
                                                            <div class="qD YB UC WC">
                                                                <a class="tatsu-shortcode pD vD bg-animation-none left-icon" data-append-query-params="true" href="https://aswinishop.com/hi/cart/44057516933320:1">
                                                                    <div>
                                                                        <span class="rD VC" data-text="BUY NOW">
                                                                            <span class="default j">BUY NOW</span>
                                                                        </span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD aB"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-TNFS17t4gWr- dD x XC gC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass c t aB">
                                                <div class="XD">
                                                    <div class="gD TB">
                                                        <div class="tatsu-R-bY5_AjWyzs PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE UE LB">
                                                            <div class="zD VE GB g">
                                                                <!--?xml version="1.0" encoding="utf-8"?-->
                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="l">
                                                                    <path d="M 8.1816406 2.5742188 L 7.375 3.21875 C 7.156 3.39475 2 7.582 2 13 C 2 16.147521 3.5928401 17.712209 4.6855469 18.425781 C 4.3767257 18.796031 4.0996391 19.167531 3.8710938 19.533203 C 3.34147 20.380601 3 21.166667 3 22 L 5 22 C 5 21.833333 5.15853 21.244399 5.5664062 20.591797 C 5.6792953 20.411174 5.8116983 20.222627 5.9570312 20.03125 C 6.5991592 20.232376 9.212928 21 12 21 C 14.7 21 16.729554 20.148831 18.257812 18.898438 C 19.786071 17.648043 20.832031 16.054686 21.832031 14.554688 L 22.287109 13.873047 L 21.707031 13.292969 C 21.707031 13.292969 18.5 10 14 10 C 11.250583 10 9.2352816 11.47912 7.8457031 13.169922 C 7.9349527 12.143686 8 11.085241 8 10 L 6 10 C 6 12.358995 5.7055204 14.791074 5.3496094 16.417969 C 4.7136869 15.842891 4 14.811366 4 13 C 4 9.723 6.4845 6.8334375 7.8125 5.5234375 C 8.3245 6.3574375 9.043625 7.6799687 9.515625 9.1679688 C 10.091625 8.8489687 10.702328 8.5768125 11.361328 8.3828125 C 10.455328 5.6388125 8.8927812 3.5233906 8.8007812 3.4003906 L 8.1816406 2.5742188 z M 14 12 C 16.8138 12 18.75825 13.489711 19.574219 14.175781 C 18.766161 15.357878 17.985481 16.538868 16.992188 17.351562 C 15.770446 18.351169 14.3 19 12 19 C 10.168409 19 8.6029981 18.650184 7.5664062 18.376953 C 9.1575551 17.065731 11.367514 16 14 16 L 14 14 C 12.05204 14 10.3064 14.486624 8.8066406 15.21875 C 9.9543167 13.498836 11.589952 12 14 12 z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="WE typo-h5 A D F G H O">
                                                                    <a>&#x917;&#x902;&#x927;&#x92A;&#x941;&#x930;&#x93E;&#x924;&#x948;&#x932;&#x93E;&#x915;&#x940;&#x936;&#x915;&#x94D;&#x924;&#x93F;</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-latqBsg0l7Cf tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD i u z">
                                                                <p>&#x917;&#x902;&#x927;&#x92A;&#x941;&#x930;&#x93E;&#x924;&#x948;&#x932;&#x93E;&#x906;&#x92A;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x94D;&#x92F;&#x93E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;? &#x917;&#x902;&#x927;&#x92A;&#x941;&#x930;&#x93E;&#x924;&#x947;&#x932;, &#x91C;&#x93F;&#x938;&#x947;&#x938;&#x941;&#x917;&#x902;&#x927;&#x93F;&#x924;&#x917;&#x949;&#x932;&#x925;&#x947;&#x930;&#x93F;&#x92F;&#x93E;&#x92F;&#x93E;&#x924;&#x93E;&#x91C;&#x93C;&#x93E;&#x936;&#x940;&#x924;&#x915;&#x93E;&#x932;&#x940;&#x928;&#x924;&#x947;&#x932;&#x915;&#x947;&#x930;&#x942;&#x92A;&#x92E;&#x947;&#x902;&#x91C;&#x93E;&#x928;&#x93E;&#x91C;&#x93E;&#x924;&#x93E;&#x939;&#x948;, &#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x90F;&#x915;&#x909;&#x924;&#x94D;&#x915;&#x943;&#x937;&#x94D;&#x91F;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x938;&#x92E;&#x93E;&#x927;&#x93E;&#x928;&#x939;&#x948;&#x964;&#x907;&#x938;&#x915;&#x947;&#x932;&#x93E;&#x92D;&#x915;&#x93E;&#x930;&#x940;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x94B;&#x902;&#x915;&#x93E;&#x905;&#x928;&#x941;&#x92D;&#x935;&#x915;&#x930;&#x947;&#x902;:</p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-a5ptSYgVFE7c PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x938;&#x942;&#x91C;&#x928;&#x915;&#x94B;&#x909;&#x932;&#x94D;&#x932;&#x947;&#x916;&#x928;&#x940;&#x92F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;: &#x92F;&#x939;&#x924;&#x947;&#x932;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x940;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x938;&#x942;&#x91C;&#x928;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;, &#x917;&#x924;&#x93F;&#x935;&#x93F;&#x927;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x94B;&#x906;&#x938;&#x93E;&#x928;&#x914;&#x930;&#x915;&#x92E;&#x926;&#x930;&#x94D;&#x926;&#x928;&#x93E;&#x915;&#x92C;&#x928;&#x93E;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-2BOXrwGm3YMl PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x917;&#x939;&#x930;&#x93E;&#x908;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x926;&#x947;&#x924;&#x93E;&#x939;&#x948;: &#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;, &#x936;&#x915;&#x94D;&#x924;&#x93F;&#x936;&#x93E;&#x932;&#x940;&#x905;&#x935;&#x92F;&#x935;&#x94B;&#x902;&#x938;&#x947;&#x92D;&#x930;&#x92A;&#x942;&#x930;&#x91C;&#x94B;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x94B;&#x938;&#x915;&#x94D;&#x930;&#x93F;&#x92F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-5kxOayqynV4m PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x930;&#x915;&#x94D;&#x924;&#x92A;&#x94D;&#x930;&#x935;&#x93E;&#x939;&#x915;&#x94B;&#x92C;&#x922;&#x93C;&#x93E;&#x935;&#x93E;&#x926;&#x947;&#x924;&#x93E;&#x939;&#x948;: &#x915;&#x94B;&#x92E;&#x932;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x92E;&#x947;&#x902;&#x938;&#x94D;&#x935;&#x938;&#x94D;&#x925;&#x930;&#x915;&#x94D;&#x924;&#x92A;&#x930;&#x93F;&#x938;&#x902;&#x91A;&#x930;&#x923;&#x915;&#x94B;&#x92A;&#x94D;&#x930;&#x94B;&#x924;&#x94D;&#x938;&#x93E;&#x939;&#x93F;&#x924;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;, &#x91C;&#x93F;&#x938;&#x938;&#x947;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x92E;&#x947;&#x902;&#x924;&#x947;&#x91C;&#x940;&#x906;&#x924;&#x940;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-DFBNJw7GpM19 PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x92E;&#x93E;&#x902;&#x938;&#x92A;&#x947;&#x936;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x940;&#x910;&#x902;&#x920;&#x928;&#x92E;&#x947;&#x902;&#x906;&#x930;&#x93E;&#x92E;: &#x92E;&#x93E;&#x902;&#x938;&#x92A;&#x947;&#x936;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x940;&#x910;&#x902;&#x920;&#x928;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x928;&#x947;&#x92E;&#x947;&#x902;&#x909;&#x932;&#x94D;&#x932;&#x947;&#x916;&#x928;&#x940;&#x92F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x940;, &#x91C;&#x94B;&#x905;&#x915;&#x94D;&#x938;&#x930;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x92A;&#x930;&#x947;&#x936;&#x93E;&#x928;&#x940;&#x915;&#x93E;&#x90F;&#x915;&#x92A;&#x94D;&#x930;&#x92E;&#x941;&#x916;&#x915;&#x93E;&#x930;&#x923;&#x939;&#x94B;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-QelQlhDXjF98 PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE GB g">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x906;&#x930;&#x93E;&#x92E;&#x926;&#x93E;&#x92F;&#x915;&#x917;&#x930;&#x94D;&#x92E;&#x93E;&#x939;&#x91F;&#x92A;&#x94D;&#x930;&#x926;&#x93E;&#x928;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;: &#x924;&#x947;&#x932;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x92E;&#x947;&#x902;&#x915;&#x94B;&#x92E;&#x932;, &#x917;&#x930;&#x94D;&#x92E;&#x93E;&#x939;&#x91F;&#x915;&#x940;&#x905;&#x928;&#x941;&#x92D;&#x942;&#x924;&#x93F;&#x926;&#x947;&#x924;&#x93E;&#x939;&#x948;, &#x915;&#x920;&#x94B;&#x930;&#x92E;&#x93E;&#x902;&#x938;&#x92A;&#x947;&#x936;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x94B;&#x906;&#x930;&#x93E;&#x92E;&#x926;&#x947;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-QADodSYjj6BR tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB">
                                                        </div>
                                                        <div class="tatsu-module oD tatsu-ruYswXbvfFYK qE none u B D S">
                                                            <div class="qD YB UC WC">
                                                                <a class="tatsu-shortcode pD vD bg-animation-none left-icon" data-append-query-params="true" href="https://aswinishop.com/hi/cart/44057516933320:1">
                                                                    <div>
                                                                        <span class="rD VC" data-text="BUY NOW">
                                                                            <span class="default j">BUY NOW</span>
                                                                        </span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD aB"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="aD be-preview lD tatsu-0ti6CVOWswhN TD PD RD">
                                <div class="OD kD y iC qC">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-v9kUfPi7CWgd dD x XC cC dC gC sC qC">
                                            <div class="tatsu-column-inner gradientClass c t aB">
                                                <div class="XD">
                                                    <div class="gD TB">
                                                        <div class="tatsu-7_D4vROFulAw PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE UE LB">
                                                            <div class="zD VE g GB">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-droplet l">
                                                                    <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="WE typo-h5 A D F G H O">
                                                                    <a>&#x924;&#x948;&#x932;&#x92A;&#x930;&#x94D;&#x923;&#x93E;&#x924;&#x948;&#x932;&#x915;&#x940;&#x936;&#x915;&#x94D;&#x924;&#x93F;</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-lHfKgptQfhEH tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD i u z">
                                                                <p>&#x924;&#x948;&#x932;&#x92A;&#x930;&#x94D;&#x923;&#x93E;&#x906;&#x92A;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x94D;&#x92F;&#x93E;&#x915;&#x930;&#x924;&#x940;&#x939;&#x948;? &#x92A;&#x935;&#x93F;&#x924;&#x94D;&#x930;&#x924;&#x948;&#x932;&#x92A;&#x930;&#x94D;&#x923;&#x93E;&#x92A;&#x94C;&#x927;&#x947;&#x915;&#x940;&#x92A;&#x924;&#x94D;&#x924;&#x93F;&#x92F;&#x94B;&#x902;&#x938;&#x947;&#x92C;&#x928;&#x93E;&#x92F;&#x939;&#x924;&#x947;&#x932;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x93E;&#x90F;&#x915;&#x92A;&#x93E;&#x930;&#x902;&#x92A;&#x930;&#x93F;&#x915;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x939;&#x948;:</p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-AdyvHf9wg3Dm PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x938;&#x939;&#x91C;&#x917;&#x924;&#x93F;: &#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x917;&#x924;&#x93F;&#x935;&#x93F;&#x927;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x94B;&#x905;&#x935;&#x93F;&#x936;&#x94D;&#x935;&#x938;&#x928;&#x940;&#x92F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x938;&#x941;&#x91A;&#x93E;&#x930;&#x942;&#x92C;&#x928;&#x93E;&#x924;&#x93E;&#x939;&#x948;, &#x905;&#x938;&#x941;&#x935;&#x93F;&#x927;&#x93E;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-0wPqhrrXh_gH PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x936;&#x930;&#x940;&#x930;&#x92A;&#x930;&#x936;&#x93E;&#x902;&#x924;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;: &#x907;&#x938;&#x915;&#x940;&#x936;&#x93E;&#x902;&#x924;&#x92A;&#x94D;&#x930;&#x915;&#x943;&#x924;&#x93F;&#x924;&#x928;&#x93E;&#x935;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x940;&#x939;&#x948;, &#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x940;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-DmjC6asJzUsC PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x935;&#x93E;&#x938;&#x94D;&#x924;&#x935;&#x93F;&#x915;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;: &#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x92A;&#x930;&#x947;&#x936;&#x93E;&#x928;&#x940;&#x915;&#x947;&#x92A;&#x94D;&#x930;&#x92C;&#x902;&#x927;&#x928;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x935;&#x93E;&#x938;&#x94D;&#x924;&#x935;&#x92E;&#x947;&#x902;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x940;, &#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x926;&#x943;&#x937;&#x94D;&#x91F;&#x93F;&#x915;&#x94B;&#x923;&#x92A;&#x94D;&#x930;&#x926;&#x93E;&#x928;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-7ynES-ocydw7 PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x915;&#x94B;&#x92C;&#x922;&#x93C;&#x93E;&#x935;&#x93E;&#x926;&#x947;&#x924;&#x93E;&#x939;&#x948;: &#x926;&#x930;&#x94D;&#x926;&#x914;&#x930;&#x938;&#x942;&#x91C;&#x928;&#x938;&#x947;&#x928;&#x93F;&#x92A;&#x91F;&#x928;&#x947;, &#x936;&#x930;&#x940;&#x930;&#x915;&#x940;&#x909;&#x92A;&#x91A;&#x93E;&#x930;&#x915;&#x94D;&#x937;&#x92E;&#x924;&#x93E;&#x913;&#x902;&#x915;&#x93E;&#x926;&#x943;&#x922;&#x93C;&#x924;&#x93E;&#x938;&#x947;&#x938;&#x92E;&#x930;&#x94D;&#x925;&#x928;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-1tnDRZM-TaA_ tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB">
                                                        </div>
                                                        <div class="tatsu-module oD tatsu-VBHQ1Crv8nDs qE none u B D S">
                                                            <div class="qD YB UC WC">
                                                                <a class="tatsu-shortcode pD vD bg-animation-none left-icon" data-append-query-params="true" href="https://aswinishop.com/hi/cart/44057516933320:1">
                                                                    <div>
                                                                        <span class="rD VC" data-text="BUY NOW">
                                                                            <span class="default j">BUY NOW</span>
                                                                        </span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD aB"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-_0oGcxjdQ9CV dD x XC dC gC sC qC">
                                            <div class="tatsu-column-inner gradientClass c t aB">
                                                <div class="XD">
                                                    <div class="gD TB">
                                                        <div class="tatsu-srMngJWbxxyi PE tatsu-module QE RE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE UE LB">
                                                            <div class="zD VE GB g">
                                                                <!--?xml version="1.0" encoding="utf-8"?-->
                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="l">
                                                                    <path d="M 16.292969 6.2929688 L 10.455078 12.130859 L 11.869141 13.544922 L 17.707031 7.7070312 L 16.292969 6.2929688 z M 22.292969 6.2929688 L 12 16.585938 L 7.7070312 12.292969 L 6.2929688 13.707031 L 12 19.414062 L 23.707031 7.7070312 L 22.292969 6.2929688 z M 1.7070312 12.292969 L 0.29296875 13.707031 L 5.5449219 18.960938 L 6.9609375 17.544922 L 1.7070312 12.292969 z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="WE typo-h5 A D F G H O">
                                                                    <a>&#x932;&#x93E;&#x935;&#x902;&#x917;&#x93E;&#x914;&#x930;&#x91F;&#x940;&#x932;&#x93E;&#x924;&#x948;&#x932;&#x93E;&#x915;&#x940;&#x936;&#x915;&#x94D;&#x924;&#x93F;</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-Rv2wmDjK761t tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD i u z">
                                                                <p>&#x932;&#x935;&#x93E;&#x902;&#x917;&#x93E;&#x914;&#x930;&#x91F;&#x940;&#x932;&#x93E;&#x906;&#x92A;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x94D;&#x92F;&#x93E;&#x915;&#x930;&#x924;&#x947;&#x939;&#x948;&#x902;? &#x932;&#x935;&#x902;&#x917;&#x93E;(&#x932;&#x94C;&#x902;&#x917;&#x915;&#x93E;&#x924;&#x947;&#x932;) &#x914;&#x930;&#x924;&#x93F;&#x932;&#x93E;(&#x938;&#x92E;&#x943;&#x926;&#x94D;&#x927;&#x924;&#x93F;&#x932;&#x915;&#x93E;&#x924;&#x947;&#x932;) &#x918;&#x941;&#x91F;&#x928;&#x947;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x932;&#x94B;&#x915;&#x92A;&#x94D;&#x930;&#x93F;&#x92F;&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x924;&#x947;&#x932;&#x939;&#x948;&#x902;:</p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-cLIAumGDytAC PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x92E;&#x93E;&#x902;&#x938;&#x92A;&#x947;&#x936;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x947;&#x924;&#x928;&#x93E;&#x935;&#x915;&#x94B;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x940;&#x922;&#x902;&#x917;&#x938;&#x947;&#x906;&#x930;&#x93E;&#x92E;&#x926;&#x947;&#x924;&#x93E;&#x939;&#x948;: &#x92F;&#x947;&#x924;&#x947;&#x932;&#x927;&#x940;&#x930;&#x947;-&#x927;&#x940;&#x930;&#x947;&#x918;&#x941;&#x91F;&#x928;&#x947;&#x915;&#x947;&#x906;&#x938;&#x92A;&#x93E;&#x938;&#x915;&#x940;&#x92E;&#x93E;&#x902;&#x938;&#x92A;&#x947;&#x936;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x94B;&#x906;&#x930;&#x93E;&#x92E;&#x926;&#x947;&#x924;&#x947;&#x939;&#x948;&#x902;, &#x91C;&#x93F;&#x938;&#x938;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x92E;&#x93F;&#x932;&#x924;&#x940;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-NN1bpyVlgVRm PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE GB g">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x918;&#x941;&#x91F;&#x928;&#x947;&#x915;&#x940;&#x938;&#x942;&#x91C;&#x928;&#x915;&#x94B;&#x938;&#x94D;&#x92A;&#x937;&#x94D;&#x91F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x915;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;: &#x932;&#x948;&#x935;&#x902;&#x917;&#x93E;&#x924;&#x947;&#x932;&#x918;&#x941;&#x91F;&#x928;&#x947;&#x915;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x92E;&#x947;&#x902;&#x938;&#x942;&#x91C;&#x928;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x928;&#x947;&#x92E;&#x947;&#x902;&#x935;&#x93F;&#x936;&#x947;&#x937;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x940;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-os6lUd0ObRWR PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x917;&#x924;&#x93F;&#x936;&#x940;&#x932;&#x924;&#x93E;&#x915;&#x94B;&#x92C;&#x922;&#x93C;&#x93E;&#x924;&#x93E;&#x939;&#x948;: &#x924;&#x93F;&#x932;&#x915;&#x93E;&#x924;&#x947;&#x932;&#x918;&#x930;&#x94D;&#x937;&#x923;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x915;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x917;&#x924;&#x93F;&#x936;&#x940;&#x932;&#x924;&#x93E;&#x92E;&#x947;&#x902;&#x935;&#x93F;&#x936;&#x947;&#x937;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x938;&#x941;&#x927;&#x93E;&#x930;&#x915;&#x930;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-1QYCNcl-BoGf PE tatsu-module rE QE tatsu-icon_card-align-left tatsu-icon_card-type-icon YE SE">
                                                            <div class="zD VE g GB">
                                                                <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg" class="n">
                                                                    <path d="M4.77404 9.93175C4.44485 9.93175 4.11565 9.80186 3.86435 9.54044L0.376956 5.91256C-0.125652 5.38974 -0.125652 4.54277 0.376956 4.02145C0.879564 3.49863 1.69226 3.4971 2.19487 4.01994L4.77404 6.70297L10.8406 0.392129C11.3432 -0.13071 12.1559 -0.13071 12.6586 0.392129C13.1611 0.914977 13.1611 1.76193 12.6586 2.28477L5.68371 9.54044C5.43243 9.80186 5.10323 9.93175 4.77404 9.93175Z" fill="currentColor"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE">
                                                                    <p>&#x939;&#x921;&#x94D;&#x921;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x94B;&#x92E;&#x91C;&#x92C;&#x942;&#x924;&#x92C;&#x928;&#x93E;&#x924;&#x93E;&#x939;&#x948;: &#x906;&#x935;&#x936;&#x94D;&#x92F;&#x915;&#x916;&#x928;&#x93F;&#x91C;&#x94B;&#x902;&#x938;&#x947;&#x92D;&#x930;&#x92A;&#x942;&#x930;&#x91C;&#x94B;&#x939;&#x921;&#x94D;&#x921;&#x93F;&#x92F;&#x94B;&#x902;&#x915;&#x94B;&#x92E;&#x91C;&#x92C;&#x942;&#x924;&#x92C;&#x928;&#x93E;&#x924;&#x93E;&#x939;&#x948;&#x914;&#x930;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x915;&#x93E;&#x930;&#x94D;&#x92F;&#x915;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-dl0uREc70qBU tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB">
                                                        </div>
                                                        <div class="tatsu-module oD tatsu-fDmoU3nIg_iF qE none u B D S">
                                                            <div class="qD YB UC WC">
                                                                <a class="tatsu-shortcode pD vD bg-animation-none left-icon" data-append-query-params="true" href="https://aswinishop.com/hi/cart/44057516933320:1">
                                                                    <div>
                                                                        <span class="rD VC" data-text="BUY NOW">
                                                                            <span class="default j">BUY NOW</span>
                                                                        </span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD aB"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-4eSr1V6A9usU ID lD tatsu-section-offset">
                <div class="LD lD SB vC">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-a0fvOHzX23UH TD PD RD SC">
                                <div class="OD kD z BC">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg YD tatsu-XW3vhCXhnGDS dD x XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="HE tatsu-module tatsu-oV5l4NHmxRC5 qE jD tatsu-image-lazyload tatsu-oV5l4NHmxRC5 EB">
                                                            <div class="tatsu-single-image-inner z ZB hB xC BD">
                                                                <div class="tatsu-single-image-padding-wrap CB"></div>
                                                                <img data-srcset="https://media.swipepages.com/2024/1/5ff6c1a81bb3e30010dc353a/copy-of-hindi-hiran-pain-oil---one-drop--instant-reilef--2--150.webp 150w,https://media.swipepages.com/2024/1/5ff6c1a81bb3e30010dc353a/copy-of-hindi-hiran-pain-oil---one-drop--instant-reilef--2--300.webp 300w,https://media.swipepages.com/2024/1/5ff6c1a81bb3e30010dc353a/copy-of-hindi-hiran-pain-oil---one-drop--instant-reilef--2--500.webp 500w,https://media.swipepages.com/2024/1/5ff6c1a81bb3e30010dc353a/copy-of-hindi-hiran-pain-oil---one-drop--instant-reilef--2--750.webp 750w,https://media.swipepages.com/2024/1/5ff6c1a81bb3e30010dc353a/copy-of-hindi-hiran-pain-oil---one-drop--instant-reilef--2--1000.webp 1000w,https://media.swipepages.com/2024/1/5ff6c1a81bb3e30010dc353a/copy-of-hindi-hiran-pain-oil---one-drop--instant-reilef--2-.jpg 1080w" sizes="(max-width: 767px) 100vw,(max-width: 1024px) 100vw,(max-width: 1377px) 580px, 580px" alt data-src="https://media.swipepages.com/2024/1/5ff6c1a81bb3e30010dc353a/copy-of-hindi-hiran-pain-oil---one-drop--instant-reilef--2-.jpg" data-extension=".jpg" data-webp="1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg YD tatsu-nIT9xWE64jA8 dD x XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-Jspzw8ob66tO h2 eE tatsu-title-wrap-h2 u LB">
                                                            <h2 class="tatsu-title hE A C E G H K z V">&#x939;&#x91C;&#x93E;&#x930;&#x94B;&#x902;&#x932;&#x94B;&#x917;&#x907;&#x938;&#x947;&#x92A;&#x938;&#x902;&#x926;&#x915;&#x930;&#x924;&#x947;&#x939;&#x948;&#x902;</h2>
                                                        </div>
                                                        <div class="tatsu-UGp5gH2bEs4- tatsu-module GE IB bB u">
                                                            <hr class="tatsu-module FE w">
                                                        </div>
                                                        <div class="tatsu-VAk5ywS2gnso PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE MB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>100% &#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x91C;&#x93F;&#x938;&#x915;&#x93E;&#x915;&#x94B;&#x908;&#x938;&#x93E;&#x907;&#x921;&#x907;&#x92B;&#x93C;&#x947;&#x915;&#x94D;&#x91F;&#x928;&#x939;&#x940;&#x902;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-_AFVR3TVZ4nD tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB FB">
                                                        </div>
                                                        <div class="tatsu-wZUSJLY40hnw PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE MB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>&#x92A;&#x939;&#x932;&#x947;&#x926;&#x93F;&#x928;&#x938;&#x947;&#x939;&#x940;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x92A;&#x930;&#x915;&#x93E;&#x92E;&#x915;&#x930;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-YuTfsPoCxKzP tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB FB">
                                                        </div>
                                                        <div class="tatsu-ZyzM0W8bETQ7 PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE MB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>&#x938;&#x92D;&#x940;&#x915;&#x947;&#x926;&#x94D;&#x935;&#x93E;&#x930;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x93F;&#x92F;&#x93E;&#x91C;&#x93E;&#x938;&#x915;&#x924;&#x93E;&#x939;&#x948;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-G6huykVVDqy0 tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB FB">
                                                        </div>
                                                        <div class="tatsu-IQ2XTlvAGusn PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE MB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>&#x905;&#x936;&#x94D;&#x935;&#x93F;&#x928;&#x940;&#x915;&#x947;&#x918;&#x930;&#x938;&#x947;- &#x90F;&#x915;&#x918;&#x930;&#x947;&#x932;&#x942;&#x928;&#x93E;&#x92E;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-ArSanI59MDNq tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB FB">
                                                        </div>
                                                        <div class="tatsu-zcc1TOFo27Sh PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE JB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>25 &#x935;&#x930;&#x94D;&#x937;&#x94B;&#x902;&#x938;&#x947;&#x905;&#x927;&#x93F;&#x915;&#x905;&#x928;&#x941;&#x92D;&#x935;&#x935;&#x93E;&#x932;&#x947;&#x935;&#x93F;&#x936;&#x947;&#x937;&#x91C;&#x94D;&#x91E;&#x94B;&#x902;&#x926;&#x94D;&#x935;&#x93E;&#x930;&#x93E;&#x924;&#x948;&#x92F;&#x93E;&#x930;&#x915;&#x93F;&#x92F;&#x93E;&#x917;&#x92F;&#x93E;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-wcBB_4sVF ID lD tatsu-section-offset">
                <div class="LD lD SB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-xzFztx6IKMme TD PD RD VD FD">
                                <div class="OD kD z rC">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-7dR-ucCjQEMg bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-v0-aRBws5C6Q tatsu-module mD MB">
                                                            <div class="hD tatsu-align-left HD i v z">
                                                                <p>
                                                                    <strong>&#x915;&#x908;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x94D;&#x924;&#x93E;&#x913;&#x902;&#x926;&#x94D;&#x935;&#x93E;&#x930;&#x93E;5 &#x938;&#x94D;&#x91F;&#x93E;&#x930;&#x930;&#x947;&#x91F;&#x93F;&#x902;&#x917;&#x926;&#x940;&#x917;&#x908;</strong>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-NHRm1UsV5w_3 tatsu-module IE OE MB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 100%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-Hf65yUE_VKhQ tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD v z">
                                                                <p>
                                                                    <span style="color: #000000;">
                                                                        <strong>&#x1F69A;&#x92E;&#x941;&#x92B;&#x93C;&#x94D;&#x924;&#x939;&#x94B;&#x92E;&#x921;&#x93F;&#x932;&#x940;&#x935;&#x930;&#x940;| &#x1F4B0;&#x938;&#x940;&#x913;&#x921;&#x940;&#x909;&#x92A;&#x932;&#x92C;&#x94D;&#x927;&#x939;&#x948;| &#x1F381;&#x905;&#x92D;&#x940;&#x932;&#x947;&#x902;11% &#x915;&#x940;&#x91B;&#x942;&#x91F;!</strong>
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module oD tD tatsu-JEsvaQJCEEns qE none B D S v LB">
                                                            <div class="qD YB UC WC">
                                                                <a class="tatsu-shortcode pD wD bg-animation-none left-icon sub-text" data-append-query-params="true" href="https://aswinishop.com/hi/cart/44057516933320:1">
                                                                    <div>
                                                                        <span class="rD DB eB MC VC" data-text="&#x916;&#x930;&#x940;&#x926;&#x947;&#x902; &#x938;&#x93F;&#x930;&#x94D;&#x92B; 239/- &#x92E;&#x947;&#x902;">
                                                                            <!-- <span class="default j">&#x916;&#x930;&#x940;&#x926;&#x947;&#x902;&#x938;&#x93F;&#x930;&#x94D;&#x92B;239/- &#x92E;&#x947;&#x902;</span> -->
                                                                              <a href="checkout.php?product_id=1"><button class="btn bt">PAY NOW</button></a>
                                                                        </span>
                                                                        <span class="sD Y j DB zB VC" data-text="&#x90F;&#x915; &#x92C;&#x942;&#x902;&#x926;, &#x924;&#x941;&#x930;&#x902;&#x924; &#x930;&#x93E;&#x939;&#x924;">
                                                                            <span class="default">&#x90F;&#x915;&#x92C;&#x942;&#x902;&#x926;, &#x924;&#x941;&#x930;&#x902;&#x924;&#x930;&#x93E;&#x939;&#x924;</span>
                                                                        </span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-_wzwLV7Hu1cB ID lD tatsu-section-offset">
                <div class="LD lD SB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-Yc0tfOvdiYhK TD PD RD VD">
                                <div class="OD y gC qC">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-2roy4Mmc1OA6 bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-olgWqHPtPOvT h2 eE tatsu-title-wrap-h2 v">
                                                            <h2 class="tatsu-title hE A C E G H K z V">&#x932;&#x94B;&#x917;&#x915;&#x94D;&#x92F;&#x93E;&#x915;&#x939;&#x930;&#x939;&#x947;&#x939;&#x948;&#x902;</h2>
                                                        </div>
                                                        <div class="tatsu-Pku1WR1EW77s tatsu-module GE qE OB bB v">
                                                            <hr class="tatsu-module FE w">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="aD be-preview lD tatsu-w0fF3cZi8h9F TD PD RD">
                                <div class="OD z">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-5lUl313hT4Bt cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-EJKzP6ShP-gB tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 80%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-2Il9rYl2_STg PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Mridula</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x92E;&#x948;&#x902;&#x939;&#x93F;&#x930;&#x928;&#x92A;&#x947;&#x928;&#x930;&#x93F;&#x932;&#x940;&#x92B;&#x924;&#x947;&#x932;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x930;&#x939;&#x93E;&#x939;&#x942;&#x902;&#x914;&#x930;&#x907;&#x938;&#x938;&#x947;&#x92E;&#x941;&#x91D;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x92E;&#x947;&#x902;&#x92E;&#x926;&#x926;&#x92E;&#x93F;&#x932;&#x940;&#x939;&#x948;&#x964;&#x92E;&#x941;&#x91D;&#x947;&#x905;&#x91A;&#x94D;&#x91B;&#x93E;&#x932;&#x917;&#x93E;&#x915;&#x93F;&#x92F;&#x939;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x914;&#x930;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x92E;&#x947;&#x902;&#x906;&#x938;&#x93E;&#x928;&#x939;&#x948;&#x964;&#x905;&#x924;&#x94D;&#x92F;&#x927;&#x93F;&#x915;&#x938;&#x93F;&#x92B;&#x93E;&#x930;&#x93F;&#x936;&#x915;&#x93F;&#x92F;&#x93E;&#x91C;&#x93E;&#x924;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-78mVBcECPjj9 cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-_j16WxWUnWar tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 100%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-1TXpazpnPmSf PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Santhalakshmi</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x92F;&#x939;&#x924;&#x947;&#x932;&#x92E;&#x947;&#x930;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x91C;&#x940;&#x935;&#x928;&#x930;&#x915;&#x94D;&#x937;&#x915;&#x930;&#x939;&#x93E;&#x939;&#x948;&#x964;&#x92E;&#x948;&#x902;&#x928;&#x947;&#x925;&#x94B;&#x921;&#x93C;&#x947;&#x939;&#x940;&#x938;&#x92E;&#x92F;&#x92E;&#x947;&#x902;&#x909;&#x932;&#x94D;&#x932;&#x947;&#x916;&#x928;&#x940;&#x92F;&#x938;&#x941;&#x927;&#x93E;&#x930;&#x926;&#x947;&#x916;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-OS4RejKs_d-6 cD AB XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-Sj18cPE6IkjH tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 80%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-WtGgAnLCqf57 PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Akbar Khan</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&quot;&#x92E;&#x948;&#x902;&#x92A;&#x93F;&#x91B;&#x932;&#x947;&#x915;&#x941;&#x91B;&#x939;&#x92B;&#x94D;&#x924;&#x94B;&#x902;&#x938;&#x947;&#x924;&#x947;&#x932;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x930;&#x939;&#x93E;&#x939;&#x942;&#x902;&#x914;&#x930;&#x92E;&#x941;&#x91D;&#x947;&#x92F;&#x939;&#x915;&#x939;&#x924;&#x947;&#x939;&#x941;&#x90F;&#x916;&#x941;&#x936;&#x940;&#x939;&#x94B;&#x930;&#x939;&#x940;&#x939;&#x948;&#x915;&#x93F;&#x92F;&#x939;&#x92E;&#x947;&#x930;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x94B;&#x915;&#x92E;&#x915;&#x930;&#x928;&#x947;&#x92E;&#x947;&#x902;&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x940;&#x930;&#x939;&#x93E;&#x939;&#x948;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="aD be-preview lD tatsu-4Uzd5Jy3nwga TD PD RD">
                                <div class="OD z">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-_on_sJt_j2Zc cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-4HFfUg4LQaOM tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 80%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-ANYcyMZx4F1C PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Venkatraman</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x907;&#x938;&#x924;&#x947;&#x932;&#x92E;&#x947;&#x902;&#x92E;&#x94C;&#x91C;&#x942;&#x926;&#x92A;&#x94D;&#x930;&#x93E;&#x915;&#x943;&#x924;&#x93F;&#x915;&#x924;&#x924;&#x94D;&#x935;&#x92E;&#x941;&#x91D;&#x947;&#x932;&#x902;&#x92C;&#x947;&#x938;&#x92E;&#x92F;&#x924;&#x915;&#x907;&#x938;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x928;&#x947;&#x92E;&#x947;&#x902;&#x906;&#x924;&#x94D;&#x92E;&#x935;&#x93F;&#x936;&#x94D;&#x935;&#x93E;&#x938;&#x92E;&#x939;&#x938;&#x942;&#x938;&#x915;&#x930;&#x93E;&#x924;&#x947;&#x939;&#x948;&#x902;&#x964;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x92A;&#x940;&#x921;&#x93C;&#x93F;&#x924;&#x926;&#x942;&#x938;&#x930;&#x94B;&#x902;&#x915;&#x94B;&#x928;&#x93F;&#x936;&#x94D;&#x91A;&#x93F;&#x924;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x907;&#x938;&#x915;&#x940;&#x905;&#x928;&#x941;&#x936;&#x902;&#x938;&#x93E;&#x915;&#x930;&#x947;&#x902;&#x917;&#x947;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-PB8B_yvBgSw6 cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-wil8E3rNHOqG tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 100%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-nNLih9LCnuro PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Nanda</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x906;&#x92F;&#x941;&#x930;&#x94D;&#x935;&#x947;&#x926;&#x93F;&#x915;&#x91C;&#x94B;&#x921;&#x93C;&#x926;&#x930;&#x94D;&#x926;&#x928;&#x93F;&#x935;&#x93E;&#x930;&#x915;&#x924;&#x947;&#x932;&#x928;&#x947;&#x92E;&#x947;&#x930;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x940;&#x905;&#x915;&#x921;&#x93C;&#x928;&#x92E;&#x947;&#x902;&#x915;&#x93E;&#x92B;&#x940;&#x92E;&#x926;&#x926;&#x915;&#x940;&#x939;&#x948;&#x964;&#x92E;&#x941;&#x91D;&#x947;&#x92C;&#x939;&#x941;&#x924;&#x916;&#x941;&#x936;&#x940;&#x939;&#x948;&#x915;&#x93F;&#x92E;&#x941;&#x91D;&#x947;&#x92F;&#x939;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x92E;&#x93F;&#x932;&#x93E;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-HHSTXAp28RPZ cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-NYeVk-qQ9HKY tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 80%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-y63Xr6bHHug7 PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Sarada</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x92E;&#x941;&#x91D;&#x947;&#x924;&#x947;&#x932;&#x915;&#x947;&#x930;&#x942;&#x92A;&#x915;&#x940;&#x938;&#x941;&#x935;&#x93F;&#x927;&#x93E;&#x92A;&#x938;&#x902;&#x926;&#x939;&#x948;&#x914;&#x930;&#x92A;&#x930;&#x93F;&#x923;&#x93E;&#x92E;&#x92C;&#x939;&#x941;&#x924;&#x905;&#x91A;&#x94D;&#x91B;&#x947;&#x930;&#x939;&#x947;&#x939;&#x948;&#x902;&#x964;&#x92E;&#x948;&#x902;&#x928;&#x93F;&#x936;&#x94D;&#x91A;&#x93F;&#x924;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x926;&#x94B;&#x92C;&#x93E;&#x930;&#x93E;&#x916;&#x930;&#x940;&#x926;&#x93E;&#x930;&#x940;&#x915;&#x930;&#x942;&#x902;&#x917;&#x93E;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="aD be-preview lD tatsu-pR5x4LT4WUnB TD PD RD">
                                <div class="OD kD z">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-BG79ff1SKE-S cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-WxfMRZHDvua- tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 80%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-QFl9cP1pMkwg PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Evangeline</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x92E;&#x948;&#x902;&#x928;&#x947;&#x905;&#x92A;&#x928;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x905;&#x928;&#x94D;&#x92F;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x906;&#x91C;&#x93C;&#x92E;&#x93E;&#x90F;&#x939;&#x948;&#x902;, &#x932;&#x947;&#x915;&#x93F;&#x928;&#x92F;&#x939;&#x905;&#x92C;&#x924;&#x915;&#x915;&#x93E;&#x938;&#x92C;&#x938;&#x947;&#x905;&#x91A;&#x94D;&#x91B;&#x93E;&#x939;&#x948;&#x964;&#x92E;&#x948;&#x902;&#x907;&#x938;&#x915;&#x940;&#x92A;&#x941;&#x930;&#x91C;&#x94B;&#x930;&#x938;&#x932;&#x93E;&#x939;&#x926;&#x947;&#x924;&#x93E;&#x939;&#x942;&#x901;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-bheg-QQ7oSba cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-ChWl0Qboc_Y7 tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 100%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-JA5Qn0qHabA2 PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Naveen</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x907;&#x938;&#x924;&#x947;&#x932;&#x928;&#x947;&#x92E;&#x947;&#x930;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x914;&#x930;&#x917;&#x924;&#x93F;&#x936;&#x940;&#x932;&#x924;&#x93E;&#x92E;&#x947;&#x902;&#x92C;&#x939;&#x941;&#x924;&#x92C;&#x921;&#x93C;&#x93E;&#x92C;&#x926;&#x932;&#x93E;&#x935;&#x932;&#x93E;&#x92F;&#x93E;&#x939;&#x948;&#x964;&#x92E;&#x948;&#x902;&#x928;&#x93F;&#x936;&#x94D;&#x91A;&#x93F;&#x924;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x926;&#x94B;&#x92C;&#x93E;&#x930;&#x93E;&#x916;&#x930;&#x940;&#x926;&#x93E;&#x930;&#x940;&#x915;&#x930;&#x942;&#x902;&#x917;&#x93E;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-NXpQt5-8vW2x cD AB XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-EQlnJFkXLg1E tatsu-module IE NE NB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 80%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-D2uz1Wvfxc3l PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE">
                                                            <div class="XE">
                                                                <div class="WE d i eB">
                                                                    <a>Venkat Rao</a>
                                                                </div>
                                                                <div class="ZE">
                                                                    <p>&#x907;&#x938;&#x924;&#x947;&#x932;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x928;&#x947;&#x915;&#x947;&#x92C;&#x93E;&#x926;&#x938;&#x947;&#x92E;&#x948;&#x902;&#x928;&#x947;&#x905;&#x92A;&#x928;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x938;&#x94D;&#x935;&#x93E;&#x938;&#x94D;&#x925;&#x94D;&#x92F;&#x92E;&#x947;&#x902;&#x909;&#x932;&#x94D;&#x932;&#x947;&#x916;&#x928;&#x940;&#x92F;&#x938;&#x941;&#x927;&#x93E;&#x930;&#x926;&#x947;&#x916;&#x93E;&#x939;&#x948;&#x964;&#x92E;&#x948;&#x902;&#x928;&#x93F;&#x936;&#x94D;&#x91A;&#x93F;&#x924;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x926;&#x942;&#x938;&#x930;&#x94B;&#x902;&#x915;&#x94B;&#x907;&#x938;&#x915;&#x940;&#x905;&#x928;&#x941;&#x936;&#x902;&#x938;&#x93E;&#x915;&#x930;&#x942;&#x902;&#x917;&#x93E;&#x964;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-ahmMD5qsaLO3 ID lD tatsu-section-offset xB">
                <div class="LD lD RB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-d4kqlW-cZcHd UD RD">
                                <div class="OD kD y gC qC">
                                    <div class="QD YC eC uC">
                                        <div class="WD lD tatsu-column-no-bg YD tatsu-OPA659xYOyS6 dD yB TC XC dC hC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD QC ZC lC wC">
                                                        <div class="tatsu-module EE tatsu-KMpXH01fRFDF xD jD">
                                                            <a class="AE">
                                                                <span class="yD DE BE l">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
                                                                        <path d="M 10 8 C 6.699219 8 4 10.699219 4 14 L 4 24 L 14 24 L 14 14 L 6 14 C 6 11.78125 7.78125 10 10 10 Z M 24 8 C 20.699219 8 18 10.699219 18 14 L 18 24 L 28 24 L 28 14 L 20 14 C 20 11.78125 21.78125 10 24 10 Z M 6 16 L 12 16 L 12 22 L 6 22 Z M 20 16 L 26 16 L 26 22 L 20 22 Z"/>
                                                                    </svg>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        <div class="tatsu-module tatsu-cwylOHmkMnef tatsu-module mD typo-testimonial A D F G H L JB YC U eC X uC">
                                                            <div class="hD tatsu-align-left HD u z">
                                                                <p>&quot;&#x92E;&#x948;&#x902;&#x928;&#x947;&#x905;&#x92A;&#x928;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x938;&#x94D;&#x935;&#x93E;&#x938;&#x94D;&#x925;&#x94D;&#x92F;&#x92E;&#x947;&#x902;&#x909;&#x932;&#x94D;&#x932;&#x947;&#x916;&#x928;&#x940;&#x92F;&#x938;&#x941;&#x927;&#x93E;&#x930;&#x926;&#x947;&#x916;&#x93E;&#x939;&#x948;&#x964;&#x926;&#x930;&#x94D;&#x926;&#x914;&#x930;&#x915;&#x920;&#x94B;&#x930;&#x924;&#x93E;&#x915;&#x92E;&#x939;&#x94B;&#x917;&#x908;&#x939;&#x948;, &#x914;&#x930;&#x905;&#x92C;&#x92E;&#x948;&#x902;&#x905;&#x927;&#x93F;&#x915;&#x938;&#x94D;&#x935;&#x924;&#x902;&#x924;&#x94D;&#x930;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x91A;&#x932;-&#x92B;&#x93F;&#x930;&#x938;&#x915;&#x924;&#x93E;&#x939;&#x942;&#x902;&#x964;&#x924;&#x947;&#x932;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x928;&#x93E;&#x92C;&#x939;&#x941;&#x924;&#x906;&#x938;&#x93E;&#x928;&#x939;&#x948;&#x964;&quot;</p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-_yNEKeujJFBv h6 eE gE u MB">
                                                            <h6 class="tatsu-title iE z A D F G H P">Kishore Sharma</h6>
                                                        </div>
                                                        <div class="tatsu-module tatsu-pBVVifRPQgUb h6 eE gE qE u">
                                                            <h6 class="tatsu-title iE z A D F G H P">
                                                                <span class="tatsu-title-inner typo-body A F G I R">Ex. GM, Public Sector</span>
                                                            </h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD YD tatsu-5-N1RCUBSO06 dD qB XC hC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass pB">
                                                <div class="XD">
                                                    <div class="gD vB uC">
                                                        <div class="HE tatsu-module tatsu-NR0gQteJR4B3 qE jD tatsu-image-lazyload tatsu-NR0gQteJR4B3 EB oB AD">
                                                            <div class="tatsu-single-image-inner hB OC bC nC xC GD">
                                                                <div class="tatsu-single-image-padding-wrap kB aC pC yC"></div>
                                                                <img data-srcset="https://media.swipepages.com/2023/2/5ff6c1a81bb3e30010dc353a/aditya-website--7--150.webp 150w,https://media.swipepages.com/2023/2/5ff6c1a81bb3e30010dc353a/aditya-website--7--300.webp 300w,https://media.swipepages.com/2023/2/5ff6c1a81bb3e30010dc353a/aditya-website--7--500.webp 500w,https://media.swipepages.com/2023/2/5ff6c1a81bb3e30010dc353a/aditya-website--7--750.webp 750w,https://media.swipepages.com/2023/2/5ff6c1a81bb3e30010dc353a/aditya-website--7-.png 900w" sizes="(max-width: 767px) 64.24vw,(max-width: 1024px) 64.24vw,(max-width: 1377px) 25.695999999999998vw, 25.695999999999998vw" alt data-src="https://media.swipepages.com/2023/2/5ff6c1a81bb3e30010dc353a/aditya-website--7-.png" data-extension=".png" data-webp="1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-6Y8mP0tzETgu ID lD tatsu-section-offset r">
                <div class="LD lD UB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-tgI1G7Bs9GkF TD PD RD">
                                <div class="OD kD z">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg ZD tatsu-PpMg8dACfmxF dD x XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-qMqmMLCoS5V7 h2 eE tatsu-title-wrap-h2 v">
                                                            <h2 class="tatsu-title hE A C E G H K z V">&#x939;&#x93F;&#x930;&#x923;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x948;&#x938;&#x947;&#x915;&#x930;&#x947;&#x902;?</h2>
                                                        </div>
                                                        <div class="tatsu-H0b4OQzZ8bsW tatsu-module tatsu-accordion tatsu-accordion-style1 qE">
                                                            <div class="tatsu-accordion-inner" data-collapsed="0">
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>Step 1</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x915;&#x941;&#x91B;&#x92C;&#x942;&#x901;&#x926;&#x947;&#x902;&#x932;&#x947;&#x902;&#x91C;&#x93F;&#x928;&#x915;&#x940;&#x906;&#x92A;&#x915;&#x94B;&#x92C;&#x938;&#x907;&#x924;&#x928;&#x940;&#x906;&#x935;&#x936;&#x94D;&#x92F;&#x915;&#x924;&#x93E;&#x939;&#x94B;&#x917;&#x940;&#x915;&#x93F;&#x906;&#x92A;&#x905;&#x92A;&#x928;&#x940;&#x924;&#x94D;&#x935;&#x91A;&#x93E;&#x915;&#x94B;&#x905;&#x924;&#x94D;&#x92F;&#x927;&#x93F;&#x915;&#x91A;&#x93F;&#x915;&#x928;&#x93E;&#x91B;&#x94B;&#x921;&#x93C;&#x947;&#x92C;&#x93F;&#x928;&#x93E;&#x915;&#x94D;&#x937;&#x947;&#x924;&#x94D;&#x930;&#x915;&#x94B;&#x939;&#x932;&#x94D;&#x915;&#x947;&#x938;&#x947;&#x922;&#x915;&#x938;&#x915;&#x947;&#x902;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>Step 2</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x924;&#x947;&#x932;&#x915;&#x94B;&#x905;&#x92A;&#x928;&#x940;&#x939;&#x925;&#x947;&#x932;&#x940;&#x92A;&#x930;&#x92B;&#x948;&#x932;&#x93E;&#x90F;&#x902;&#x914;&#x930;&#x938;&#x941;&#x928;&#x93F;&#x936;&#x94D;&#x91A;&#x93F;&#x924;&#x915;&#x930;&#x947;&#x902;&#x915;&#x93F;&#x924;&#x947;&#x932;&#x906;&#x92A;&#x915;&#x947;&#x939;&#x93E;&#x925;&#x938;&#x947;&#x91F;&#x92A;&#x915;&#x928;&#x930;&#x939;&#x93E;&#x939;&#x94B;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>Step 3</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x905;&#x92A;&#x928;&#x940;&#x939;&#x925;&#x947;&#x932;&#x940;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x915;&#x947;, &#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x93F;&#x924;&#x915;&#x94D;&#x937;&#x947;&#x924;&#x94D;&#x930;&#x92A;&#x930;&#x90F;&#x915;&#x924;&#x930;&#x92B;&#x938;&#x947;&#x926;&#x942;&#x938;&#x930;&#x940;&#x924;&#x930;&#x92B;(&#x915;&#x947;&#x935;&#x932;&#x90F;&#x915;&#x926;&#x93F;&#x936;&#x93E;&#x92E;&#x947;&#x902;), &#x91C;&#x939;&#x93E;&#x902;&#x906;&#x92A;&#x915;&#x94B;&#x926;&#x930;&#x94D;&#x926;&#x939;&#x94B;&#x930;&#x939;&#x93E;&#x939;&#x948;, &#x935;&#x939;&#x93E;&#x902;&#x924;&#x947;&#x932;&#x938;&#x947;&#x927;&#x940;&#x930;&#x947;-&#x927;&#x940;&#x930;&#x947;&#x92E;&#x93E;&#x932;&#x93F;&#x936;&#x915;&#x930;&#x947;&#x902;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>Step 4</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x906;&#x930;&#x93E;&#x92E;&#x915;&#x930;&#x947;&#x902;&#x914;&#x930;&#x924;&#x947;&#x932;&#x915;&#x94B;&#x938;&#x94B;&#x916;&#x928;&#x947;&#x926;&#x947;&#x902;</p>
                                                                        <p>&#x915;&#x941;&#x91B;&#x92E;&#x93F;&#x928;&#x91F;&#x94B;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x906;&#x930;&#x93E;&#x92E;&#x915;&#x930;&#x947;&#x902;, &#x91C;&#x93F;&#x938;&#x938;&#x947;&#x924;&#x947;&#x932;&#x906;&#x92A;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x92A;&#x930;&#x915;&#x93E;&#x92E;&#x915;&#x930;&#x938;&#x915;&#x947;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-1zesb_jwL_1U dD x XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="HE tatsu-module tatsu-jhnhhnlUZcoS qE jD tatsu-image-lazyload tatsu-jhnhhnlUZcoS EB">
                                                            <div class="tatsu-single-image-inner gB KC">
                                                                <div class="tatsu-single-image-padding-wrap CB"></div>
                                                                <img data-srcset="https://media.swipepages.com/2023/12/5ff6c1a81bb3e30010dc353a/hiran-how-to-use-150.webp 150w,https://media.swipepages.com/2023/12/5ff6c1a81bb3e30010dc353a/hiran-how-to-use-300.webp 300w,https://media.swipepages.com/2023/12/5ff6c1a81bb3e30010dc353a/hiran-how-to-use-500.webp 500w,https://media.swipepages.com/2023/12/5ff6c1a81bb3e30010dc353a/hiran-how-to-use-750.webp 750w,https://media.swipepages.com/2023/12/5ff6c1a81bb3e30010dc353a/hiran-how-to-use-1000.webp 1000w,https://media.swipepages.com/2023/12/5ff6c1a81bb3e30010dc353a/hiran-how-to-use.png 1080w" sizes="(max-width: 767px) 100vw,(max-width: 1024px) 100vw,(max-width: 1377px) 580px, 580px" alt data-src="https://media.swipepages.com/2023/12/5ff6c1a81bb3e30010dc353a/hiran-how-to-use.png" data-extension=".png" data-webp="1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-YNhwKW3Dqqqk ID lD tatsu-section-offset">
                <div class="LD lD UB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-_eJLBWOV0okj TD PD RD VD">
                                <div class="OD y gC qC">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-74iWDdC0gUiN bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-ZG_B3ebI3_hl h2 eE tatsu-title-wrap-h2 v">
                                                            <h2 class="tatsu-title hE A C E G H K z V">&#x905;&#x936;&#x94D;&#x935;&#x93F;&#x928;&#x940;&#x938;&#x947;- &#x92A;&#x935;&#x93F;&#x924;&#x94D;&#x930;&#x924;&#x93E;&#x915;&#x93E;&#x918;&#x930;</h2>
                                                        </div>
                                                        <div class="tatsu-RlTozfxC8gVG tatsu-module GE v OB bB">
                                                            <hr class="tatsu-module FE w">
                                                        </div>
                                                        <div class="tatsu-module tatsu-hyFocOiIQ-Vd tatsu-module mD qE HB">
                                                            <div class="hD nD HD i v HC qC">
                                                                <p>&#x905;&#x936;&#x94D;&#x935;&#x93F;&#x928;&#x940;&#x915;&#x93E;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x92A;&#x94B;&#x930;&#x94D;&#x91F;&#x92B;&#x94B;&#x932;&#x93F;&#x92F;&#x94B;&#x917;&#x941;&#x923;&#x935;&#x924;&#x94D;&#x924;&#x93E;&#x91A;&#x93E;&#x939;&#x928;&#x947;&#x935;&#x93E;&#x932;&#x947;&#x909;&#x92A;&#x92D;&#x94B;&#x915;&#x94D;&#x924;&#x93E;&#x913;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x938;&#x94D;&#x92A;&#x937;&#x94D;&#x91F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x935;&#x93F;&#x92D;&#x947;&#x926;&#x93F;&#x924;&#x932;&#x93E;&#x92D;&#x94B;&#x902;&#x915;&#x947;&#x938;&#x93E;&#x925;&#x935;&#x93F;&#x936;&#x94D;&#x935;&#x938;&#x94D;&#x924;&#x930;&#x940;&#x92F;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x932;&#x93E;&#x924;&#x93E;&#x939;&#x948;&#x964;&#x907;&#x938;&#x915;&#x940;&#x905;&#x924;&#x94D;&#x92F;&#x93E;&#x927;&#x941;&#x928;&#x93F;&#x915;&#x935;&#x93F;&#x928;&#x93F;&#x930;&#x94D;&#x92E;&#x93E;&#x923;&#x938;&#x941;&#x935;&#x93F;&#x927;&#x93E;&#x938;&#x94D;&#x935;&#x91A;&#x94D;&#x91B;&#x924;&#x93E;&#x914;&#x930;&#x92C;&#x947;&#x902;&#x91A;&#x92E;&#x93E;&#x930;&#x94D;&#x915;&#x935;&#x93F;&#x928;&#x93F;&#x930;&#x94D;&#x92E;&#x93E;&#x923;&#x92A;&#x94D;&#x930;&#x925;&#x93E;&#x913;&#x902;&#x915;&#x940;&#x915;&#x920;&#x94B;&#x930;&#x906;&#x935;&#x936;&#x94D;&#x92F;&#x915;&#x924;&#x93E;&#x913;&#x902;&#x915;&#x94B;&#x92A;&#x942;&#x930;&#x93E;&#x915;&#x930;&#x924;&#x940;&#x939;&#x948;&#x964;</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="aD be-preview lD tatsu-k15vZit5Rzb1 TD PD RD dB">
                                <div class="OD y IC gC qC">
                                    <div class="QD">
                                        <div class="WD lD YD tatsu-gIxseqKHaVg5 cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass b t aB">
                                                <div class="XD">
                                                    <div class="gD VB fC">
                                                        <div class="tatsu-module EE tatsu-InolN3StEtGH xD iD">
                                                            <a class="AE">
                                                                <span class="yD DE CE k">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">
                                                                        <path fill="#455A64" d="M9,34c0,0,0,9,14.517,9C39,43,39,34,39,34v-3c0,0-2.903,6-15.483,6C10.936,37,9,31,9,31V34z"/>
                                                                        <path fill="#37474F" d="M24,4c-7.851,0-14,4.832-14,11s6.149,11,14,11s14-4.832,14-11S31.851,4,24,4L24,4z"/>
                                                                        <path fill="#37474F" d="M24,24c-8.818,0-15,3.134-15,7s6.182,7,15,7s15-3.134,15-7S32.818,24,24,24L24,24z"/>
                                                                        <path fill="#BBDEFB" d="M24 7A11 8 0 1 0 24 23A11 8 0 1 0 24 7Z"/>
                                                                        <path fill="#FFF" d="M13 15c0 .699.137 1.375.368 2.021l9.664-9.986C17.412 7.393 13 10.82 13 15zM16.563 20.881L29.25 7.969c-1.08-.428-2.274-.718-3.535-.861L14.355 18.846C14.934 19.611 15.686 20.295 16.563 20.881z"/>
                                                                        <path fill="#FFCCBC" d="M24,26c-8.371,0-13,2.956-13,5s4.629,5,13,5c8.371,0,13-2.956,13-5S32.371,26,24,26z"/>
                                                                        <path fill="#FFAB91" d="M11,31c0,1.145,1.453,2.574,4.198,3.611c0.039,0.015,0.08,0.028,0.119,0.043c0.188,0.069,0.389,0.135,0.589,0.2c-0.717-0.634-1.1-1.28-1.1-1.854c0-2.044,4.652-5,13.064-5c3.24,0,5.91,0.443,7.984,1.099c-0.547-0.475-1.277-0.94-2.206-1.36c-0.01-0.004-0.021-0.009-0.031-0.014c-0.538-0.241-1.138-0.468-1.798-0.672c-0.011-0.004-0.021-0.007-0.031-0.01c-0.234-0.073-0.487-0.139-0.738-0.205c-0.221-0.058-0.445-0.113-0.677-0.167c-0.222-0.051-0.443-0.102-0.676-0.147c-0.462-0.091-0.938-0.174-1.441-0.243c-0.143-0.02-0.296-0.033-0.441-0.051c-0.438-0.053-0.888-0.098-1.354-0.133c-0.178-0.013-0.356-0.025-0.539-0.036C25.303,26.025,24.668,26,24,26C15.629,26,11,28.956,11,31z"/>
                                                                    </svg>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        <div class="tatsu-module tatsu-w1LR4tLuaMIy h5 eE fE qE v HB">
                                                            <h5 class="tatsu-title hE A D F G H O m z">&#x92C;&#x93E;&#x932;&#x90F;&#x935;&#x902;&#x924;&#x94D;&#x935;&#x91A;&#x93E;&#x915;&#x940;&#x926;&#x947;&#x916;&#x92D;&#x93E;&#x932;</h5>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD Z f aB fB"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD lD YD tatsu-C28_4gfCnHtE cD AB XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass b t aB">
                                                <div class="XD">
                                                    <div class="gD VB fC">
                                                        <div class="tatsu-module EE tatsu-DrMX6uW4Lzl7 xD iD">
                                                            <a class="AE">
                                                                <span class="yD DE CE k">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
                                                                        <path fill="#8bc34a" d="M25,21.4c-12.2,0-18-8.4-18.2-8.7c-0.5-0.7-0.3-1.6,0.4-2.1c0.7-0.5,1.6-0.3,2.1,0.4 c0.2,0.3,5.7,8.3,17.6,7.3c0.8-0.1,1.5,0.6,1.6,1.4c0.1,0.8-0.6,1.5-1.4,1.6C26.4,21.3,25.7,21.4,25,21.4z"/>
                                                                        <path fill="#8bc34a" d="M18.6,28.2c7.1,2.6,17.5-3.7,19.9-5.1c-4.2-1.9-6.9-13.3-14.2-14.9c-5.2-1.1-9,1.5-8.1,8.5 C11.6,20.1,13.6,26.3,18.6,28.2z"/>
                                                                        <path fill="#689f38" d="M24.3,8.2c7.4,1.5,10.1,13,14.2,14.9c0,0,0,0,0,0c-3.4,0.1-10.2-0.7-22.4-6.4c0,0,0,0,0,0 C15.3,9.7,19.1,7.2,24.3,8.2z"/>
                                                                        <path fill="#00bcd4" d="M6,26c0,7.9,5.1,10.5,12.1,13h11.8C36.9,36.6,42,33.9,42,26H6z"/>
                                                                        <path fill="#00bcd4" d="M18,37h12v4H18V37z"/>
                                                                        <path fill="#006b6b" d="M41.1,31c0.6-1.4,0.9-3,0.9-5H6c0,2,0.3,3.6,0.9,5H41.1z"/>
                                                                    </svg>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        <div class="tatsu-module tatsu-vCNFPlM80xB9 h5 eE fE qE v HB">
                                                            <h5 class="tatsu-title hE m z A D F G H O">&#x92A;&#x94C;&#x937;&#x94D;&#x91F;&#x93F;&#x915;&#x92D;&#x94B;&#x91C;&#x928;</h5>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD Z f aB fB"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD YD tatsu-piqx68mW5bmO cD AB XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass b t aB">
                                                <div class="XD">
                                                    <div class="gD VB fC">
                                                        <div class="tatsu-module EE tatsu-mBrTHgJlzFQc xD iD">
                                                            <a class="AE">
                                                                <span class="yD DE CE k">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
                                                                        <path fill="#FF3D00" d="M42.5,12l-3.6-3.5C37.3,7.6,35.5,7,33.5,7c-4.2,0-7.8,2.5-9.5,6c-1.7-3.6-5.3-6-9.5-6C8.7,7,4,11.7,4,17.5c0,3,1.2,5.6,3.2,7.5L24,42l17.1-17.3c1.8-1.8,2.9-4.4,2.9-7.2C44,15.5,43.4,13.6,42.5,12z"/>
                                                                        <path fill="#FFF" d="M38.9,8.5L24,23.5l-7.2-7.2c-1-1-2.6-1-3.5,0c-1,1-1,2.6,0,3.5L24,30.5L42.5,12C41.6,10.6,40.4,9.4,38.9,8.5z"/>
                                                                    </svg>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        <div class="tatsu-module tatsu-CV-Ol06GtD2d h5 eE fE qE v">
                                                            <h5 class="tatsu-title hE m z A D F G H O">&#x938;&#x94D;&#x935;&#x93E;&#x938;&#x94D;&#x925;&#x94D;&#x92F;&#x926;&#x947;&#x916;&#x92D;&#x93E;&#x932;</h5>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD Z f aB fB"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="aD be-preview lD tatsu-bPTV3yTSA5S_ TD PD RD">
                                <div class="OD kD z">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg YD tatsu-qC1e1CTY43m1 dD x XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-JS7R_BC2rDQy h2 eE tatsu-title-wrap-h2 u LB">
                                                            <h2 class="tatsu-title hE A C E G H K z V">&#x905;&#x936;&#x94D;&#x935;&#x93F;&#x928;&#x940;&#x915;&#x947;&#x92C;&#x93E;&#x930;&#x947;&#x92E;&#x947;&#x902;</h2>
                                                        </div>
                                                        <div class="tatsu-nvXh4Y2R5_8P tatsu-module GE IB bB u">
                                                            <hr class="tatsu-module FE w">
                                                        </div>
                                                        <div class="tatsu-owsTaD5ubbR3 PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE MB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>1994 &#x938;&#x947;- &#x92D;&#x93E;&#x930;&#x924;&#x92E;&#x947;&#x902;&#x938;&#x92C;&#x938;&#x947;&#x92A;&#x941;&#x930;&#x93E;&#x928;&#x947;&#x914;&#x930;&#x92A;&#x94D;&#x930;&#x924;&#x93F;&#x937;&#x94D;&#x920;&#x93F;&#x924;&#x90F;&#x92B;&#x90F;&#x92E;&#x938;&#x940;&#x91C;&#x940;&#x92C;&#x94D;&#x930;&#x93E;&#x902;&#x921;&#x94B;&#x902;&#x92E;&#x947;&#x902;&#x938;&#x947;&#x90F;&#x915;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-NE5zc9_FrOnA tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB FB">
                                                        </div>
                                                        <div class="tatsu-9IvZDpED1zeK PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE MB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>&#x932;&#x93E;&#x916;&#x94B;&#x902;&#x917;&#x94D;&#x930;&#x93E;&#x939;&#x915;- &#x935;&#x947;&#x938;&#x92D;&#x940;&#x91C;&#x93F;&#x928;&#x94D;&#x939;&#x94B;&#x902;&#x928;&#x947;&#x907;&#x938;&#x915;&#x947;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x94B;&#x902;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x93F;&#x92F;&#x93E;&#x939;&#x948;, &#x924;&#x92C;&#x938;&#x947;&#x905;&#x936;&#x94D;&#x935;&#x93F;&#x928;&#x940;&#x915;&#x947;&#x938;&#x93E;&#x925;&#x92C;&#x928;&#x947;&#x939;&#x941;&#x90F;&#x939;&#x948;&#x902;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-Zs87-e945xs7 tatsu-module GE u">
                                                            <hr class="tatsu-module FE z BB FB">
                                                        </div>
                                                        <div class="tatsu-IRO6Q-pGmIHK PE tatsu-module QE tatsu-icon_card-vertical-align-top tatsu-icon_card-align-left tatsu-icon_card-type-icon tatsu-icon_plain TE qE MB">
                                                            <div class="zD">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="l">
                                                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                                                                </svg>
                                                            </div>
                                                            <div class="XE">
                                                                <div class="ZE typo-h6 A D F G H P">
                                                                    <p>&#x932;&#x94B;&#x917;&#x92E;&#x941;&#x928;&#x93E;&#x92B;&#x93E;&#x928;&#x939;&#x940;&#x902;- &#x938;&#x92E;&#x93E;&#x91C;&#x92E;&#x947;&#x902;&#x938;&#x915;&#x94D;&#x930;&#x93F;&#x92F;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x92F;&#x94B;&#x917;&#x926;&#x93E;&#x928;&#x926;&#x947;&#x930;&#x939;&#x947;&#x939;&#x948;&#x902;</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg YD tatsu-HzfdjgnE0RfX dD x XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="HE tatsu-module tatsu-mkknZLsTLeL5 qE jD tatsu-image-lazyload tatsu-mkknZLsTLeL5 EB">
                                                            <div class="tatsu-single-image-inner gB PC jC oC">
                                                                <div class="tatsu-single-image-padding-wrap lB"></div>
                                                                <img data-srcset="https://media.swipepages.com/2021/7/hair-care-products-1-150.webp 150w,https://media.swipepages.com/2021/7/hair-care-products-1-300.webp 300w,https://media.swipepages.com/2021/7/hair-care-products-1-500.webp 500w,https://media.swipepages.com/2021/7/hair-care-products-1-750.webp 750w,https://media.swipepages.com/2021/7/hair-care-products-1.png 864w" sizes="(max-width: 767px) 100vw,(max-width: 1024px) 129.445vw,(max-width: 1377px) 580px, 580px" alt data-src="https://media.swipepages.com/2021/7/hair-care-products-1.png" data-extension=".png" data-webp="1">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-bvf8KyXk9Zhs ID lD tatsu-section-offset r">
                <div class="LD lD UB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-dxO825frlqaY TD PD RD VD">
                                <div class="OD kD z">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-pwn3pS4QCa39 bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-idinHhUuSV-n h2 eE tatsu-title-wrap-h2 v KB">
                                                            <h2 class="tatsu-title hE A C E G H K z V">Frequently Asked Questions (FAQs)</h2>
                                                        </div>
                                                        <div class="tatsu-l6yboL6PpjCi tatsu-module tatsu-accordion tatsu-accordion-style1 qE">
                                                            <div class="tatsu-accordion-inner" data-collapsed="0">
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>&#x911;&#x930;&#x94D;&#x921;&#x930;&#x915;&#x948;&#x938;&#x947;&#x915;&#x930;&#x947;&#x902;?</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x939;&#x93F;&#x930;&#x928;&#x92A;&#x947;&#x928;&#x930;&#x93F;&#x932;&#x940;&#x92B;&#x911;&#x92F;&#x932;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x915;&#x930;&#x928;&#x93E;&#x906;&#x938;&#x93E;&#x928;&#x914;&#x930;&#x938;&#x941;&#x935;&#x93F;&#x927;&#x93E;&#x91C;&#x928;&#x915;&#x939;&#x948;&#x964;&#x92C;&#x938;&#x939;&#x92E;&#x93E;&#x930;&#x940;&#x935;&#x947;&#x92C;&#x938;&#x93E;&#x907;&#x91F;https://aswinishop.com/products/hiran-pain-relief-oil &#x92A;&#x930;&#x91C;&#x93E;&#x90F;&#x902;, &#x935;&#x939;&#x92E;&#x93E;&#x924;&#x94D;&#x930;&#x93E;&#x91A;&#x941;&#x928;&#x947;&#x902;&#x91C;&#x93F;&#x938;&#x947;&#x906;&#x92A;&#x916;&#x930;&#x940;&#x926;&#x928;&#x93E;&#x91A;&#x93E;&#x939;&#x924;&#x947;&#x939;&#x948;&#x902;, &#x914;&#x930;&#x907;&#x938;&#x947;&#x905;&#x92A;&#x928;&#x947;&#x915;&#x93E;&#x930;&#x94D;&#x91F;&#x92E;&#x947;&#x902;&#x91C;&#x94B;&#x921;&#x93C;&#x947;&#x902;&#x964;&#x91A;&#x947;&#x915;&#x906;&#x909;&#x91F;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x906;&#x917;&#x947;&#x92C;&#x922;&#x93C;&#x947;&#x902;, &#x905;&#x92A;&#x928;&#x93E;&#x936;&#x93F;&#x92A;&#x93F;&#x902;&#x917;&#x935;&#x93F;&#x935;&#x930;&#x923;&#x92D;&#x930;&#x947;&#x902;&#x914;&#x930;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x92A;&#x942;&#x930;&#x93E;&#x915;&#x930;&#x928;&#x947;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x905;&#x92A;&#x928;&#x940;&#x92A;&#x938;&#x902;&#x926;&#x940;&#x926;&#x93E;&#x92D;&#x941;&#x917;&#x924;&#x93E;&#x928;&#x935;&#x93F;&#x927;&#x93F;&#x91A;&#x941;&#x928;&#x947;&#x902;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>&#x915;&#x940;&#x92E;&#x924;&#x915;&#x94D;&#x92F;&#x93E;&#x939;&#x948;?</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x939;&#x93F;&#x930;&#x928;&#x92A;&#x947;&#x928;&#x930;&#x93F;&#x932;&#x940;&#x92B;&#x911;&#x92F;&#x932;&#x915;&#x940;&#x915;&#x940;&#x92E;&#x924;&#x909;&#x938;&#x92E;&#x93E;&#x924;&#x94D;&#x930;&#x93E;&#x92F;&#x93E;&#x92C;&#x94B;&#x924;&#x932;&#x94B;&#x902;&#x915;&#x940;&#x938;&#x902;&#x916;&#x94D;&#x92F;&#x93E;&#x92A;&#x930;&#x928;&#x93F;&#x930;&#x94D;&#x92D;&#x930;&#x915;&#x930;&#x924;&#x940;&#x939;&#x948;&#x91C;&#x93F;&#x938;&#x947;&#x906;&#x92A;&#x916;&#x930;&#x940;&#x926;&#x928;&#x93E;&#x91A;&#x93E;&#x939;&#x924;&#x947;&#x939;&#x948;&#x902;&#x964;&#x928;&#x935;&#x940;&#x928;&#x924;&#x92E;&#x92E;&#x942;&#x932;&#x94D;&#x92F;&#x928;&#x93F;&#x930;&#x94D;&#x927;&#x93E;&#x930;&#x923;&#x91C;&#x93E;&#x928;&#x915;&#x93E;&#x930;&#x940;&#x914;&#x930;&#x915;&#x93F;&#x938;&#x940;&#x92D;&#x940;&#x91A;&#x932;&#x930;&#x939;&#x940;&#x91B;&#x942;&#x91F;&#x92F;&#x93E;&#x935;&#x93F;&#x936;&#x947;&#x937;&#x911;&#x92B;&#x93C;&#x930;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x943;&#x92A;&#x92F;&#x93E;&#x939;&#x92E;&#x93E;&#x930;&#x940;&#x935;&#x947;&#x92C;&#x938;&#x93E;&#x907;&#x91F;https://aswinishop.com/products/hiran-pain-relief-oil &#x926;&#x947;&#x916;&#x947;&#x902;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>&#x92E;&#x941;&#x91D;&#x947;&#x905;&#x92A;&#x928;&#x93E;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x928;&#x939;&#x940;&#x902;&#x92E;&#x93F;&#x932;&#x93E;, &#x92E;&#x941;&#x91D;&#x947;&#x915;&#x94D;&#x92F;&#x93E;&#x915;&#x930;&#x928;&#x93E;&#x91A;&#x93E;&#x939;&#x93F;&#x90F;?</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x92F;&#x926;&#x93F;&#x906;&#x92A;&#x915;&#x94B;&#x905;&#x92A;&#x928;&#x93E;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x92A;&#x94D;&#x930;&#x93E;&#x92A;&#x94D;&#x924;&#x928;&#x939;&#x940;&#x902;&#x939;&#x941;&#x906;&#x939;&#x948;, &#x924;&#x94B;&#x915;&#x943;&#x92A;&#x92F;&#x93E;&#x939;&#x92E;&#x93E;&#x930;&#x940;&#x917;&#x94D;&#x930;&#x93E;&#x939;&#x915;&#x938;&#x947;&#x935;&#x93E;&#x91F;&#x940;&#x92E;&#x938;&#x947;1800-843-5599 &#x92A;&#x930;&#x938;&#x941;&#x92C;&#x939;10 &#x92C;&#x91C;&#x947;&#x938;&#x947;&#x936;&#x93E;&#x92E;5 &#x92C;&#x91C;&#x947;(&#x938;&#x94B;&#x92E;-&#x936;&#x928;&#x93F;) &#x915;&#x947;&#x92C;&#x940;&#x91A;&#x938;&#x902;&#x92A;&#x930;&#x94D;&#x915;&#x915;&#x930;&#x947;&#x902;/ &#x905;&#x92A;&#x928;&#x947;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x935;&#x93F;&#x935;&#x930;&#x923;&#x915;&#x947;&#x938;&#x93E;&#x925;&#x939;&#x92E;&#x947;&#x902;info@aswini.com &#x92A;&#x930;&#x92E;&#x947;&#x932;&#x915;&#x930;&#x947;&#x902;&#x964;&#x939;&#x92E;&#x924;&#x941;&#x930;&#x902;&#x924;&#x938;&#x92E;&#x938;&#x94D;&#x92F;&#x93E;&#x915;&#x940;&#x91C;&#x93E;&#x902;&#x91A;&#x915;&#x930;&#x947;&#x902;&#x917;&#x947;&#x914;&#x930;&#x906;&#x92A;&#x915;&#x94B;&#x921;&#x93F;&#x932;&#x940;&#x935;&#x930;&#x940;&#x938;&#x94D;&#x925;&#x93F;&#x924;&#x93F;&#x92F;&#x93E;&#x938;&#x92E;&#x93E;&#x927;&#x93E;&#x928;&#x92A;&#x930;&#x905;&#x92A;&#x921;&#x947;&#x91F;&#x92A;&#x94D;&#x930;&#x926;&#x93E;&#x928;&#x915;&#x930;&#x947;&#x902;&#x917;&#x947;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x948;&#x938;&#x947;&#x915;&#x930;&#x947;&#x902;?</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x92A;&#x94D;&#x930;&#x92D;&#x93E;&#x935;&#x93F;&#x924;&#x915;&#x94D;&#x937;&#x947;&#x924;&#x94D;&#x930;&#x92A;&#x930;&#x924;&#x947;&#x932;&#x915;&#x940;&#x915;&#x941;&#x91B;&#x92C;&#x942;&#x902;&#x926;&#x947;&#x902;&#x932;&#x917;&#x93E;&#x90F;&#x902;, &#x92F;&#x939;&#x938;&#x941;&#x928;&#x93F;&#x936;&#x94D;&#x91A;&#x93F;&#x924;&#x915;&#x930;&#x947;&#x902;&#x915;&#x93F;&#x906;&#x92A;&#x915;&#x940;&#x924;&#x94D;&#x935;&#x91A;&#x93E;&#x905;&#x924;&#x94D;&#x92F;&#x927;&#x93F;&#x915;&#x91A;&#x93F;&#x92A;&#x91A;&#x93F;&#x92A;&#x940;&#x928;&#x939;&#x94B;&#x964;&#x924;&#x947;&#x932;&#x915;&#x94B;&#x938;&#x92E;&#x93E;&#x928;&#x930;&#x942;&#x92A;&#x938;&#x947;&#x92B;&#x948;&#x932;&#x93E;&#x90F;&#x902;&#x914;&#x930;&#x930;&#x948;&#x916;&#x93F;&#x915;&#x917;&#x924;&#x93F;&#x92E;&#x947;&#x902;&#x927;&#x940;&#x930;&#x947;&#x938;&#x947;&#x92E;&#x93E;&#x932;&#x93F;&#x936;&#x915;&#x930;&#x947;&#x902;&#x964;&#x932;&#x917;&#x93E;&#x928;&#x947;&#x915;&#x947;&#x92C;&#x93E;&#x926;&#x915;&#x941;&#x91B;&#x92E;&#x93F;&#x928;&#x91F;&#x906;&#x930;&#x93E;&#x92E;&#x915;&#x930;&#x915;&#x947;&#x924;&#x947;&#x932;&#x915;&#x94B;&#x938;&#x94B;&#x916;&#x928;&#x947;&#x926;&#x947;&#x902;&#x964;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x906;&#x935;&#x936;&#x94D;&#x92F;&#x915;&#x924;&#x93E;&#x928;&#x941;&#x938;&#x93E;&#x930;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x947;&#x902;&#x964;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x915;&#x947;&#x92C;&#x93E;&#x930;&#x947;&#x92E;&#x947;&#x902;&#x905;&#x927;&#x93F;&#x915;&#x91C;&#x93E;&#x928;&#x915;&#x93E;&#x930;&#x940;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x943;&#x92A;&#x92F;&#x93E;https://aswinishop.com/products/hiran-pain-relief-oil &#x92A;&#x930;&#x91C;&#x93E;&#x90F;&#x902;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>&#x915;&#x94D;&#x92F;&#x93E;&#x938;&#x940;&#x913;&#x921;&#x940;&#x909;&#x92A;&#x932;&#x92C;&#x94D;&#x927;&#x939;&#x948;?</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x939;&#x93E;&#x902;, &#x939;&#x92E;&#x91A;&#x92F;&#x928;&#x93F;&#x924;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x94B;&#x902;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x948;&#x936;&#x911;&#x928;&#x921;&#x93F;&#x932;&#x940;&#x935;&#x930;&#x940;&#x935;&#x93F;&#x915;&#x932;&#x94D;&#x92A;&#x92A;&#x94D;&#x930;&#x926;&#x93E;&#x928;&#x915;&#x930;&#x924;&#x947;&#x939;&#x948;&#x902;&#x964;&#x915;&#x943;&#x92A;&#x92F;&#x93E;&#x927;&#x94D;&#x92F;&#x93E;&#x928;&#x926;&#x947;&#x902;&#x915;&#x93F;&#x92F;&#x939;&#x92D;&#x941;&#x917;&#x924;&#x93E;&#x928;&#x935;&#x93F;&#x927;&#x93F;&#x915;&#x941;&#x91B;&#x928;&#x93F;&#x92F;&#x92E;&#x94B;&#x902;&#x914;&#x930;&#x936;&#x930;&#x94D;&#x924;&#x94B;&#x902;&#x915;&#x947;&#x905;&#x927;&#x940;&#x928;&#x939;&#x94B;&#x938;&#x915;&#x924;&#x940;&#x939;&#x948;, &#x91C;&#x948;&#x938;&#x947;&#x905;&#x924;&#x93F;&#x930;&#x93F;&#x915;&#x94D;&#x924;&#x936;&#x941;&#x932;&#x94D;&#x915;&#x92F;&#x93E;&#x938;&#x94D;&#x925;&#x93E;&#x928;&#x915;&#x947;&#x906;&#x927;&#x93E;&#x930;&#x92A;&#x930;&#x909;&#x92A;&#x932;&#x92C;&#x94D;&#x927;&#x924;&#x93E;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>&#x911;&#x930;&#x94D;&#x921;&#x930;&#x915;&#x948;&#x938;&#x947;&#x91F;&#x94D;&#x930;&#x948;&#x915;&#x915;&#x930;&#x947;&#x902;?</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x90F;&#x915;&#x92C;&#x93E;&#x930;&#x906;&#x92A;&#x915;&#x93E;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x92A;&#x94D;&#x932;&#x947;&#x938;&#x939;&#x94B;&#x91C;&#x93E;&#x928;&#x947;&#x92A;&#x930;, &#x906;&#x92A;&#x915;&#x94B;&#x91F;&#x94D;&#x930;&#x948;&#x915;&#x93F;&#x902;&#x917;&#x928;&#x902;&#x92C;&#x930;&#x915;&#x947;&#x938;&#x93E;&#x925;&#x90F;&#x915;&#x92A;&#x941;&#x937;&#x94D;&#x91F;&#x93F;&#x915;&#x930;&#x923;&#x908;&#x92E;&#x947;&#x932;&#x92A;&#x94D;&#x930;&#x93E;&#x92A;&#x94D;&#x924;&#x939;&#x94B;&#x917;&#x93E;&#x964;&#x906;&#x92A;&#x907;&#x938;&#x928;&#x902;&#x92C;&#x930;&#x915;&#x93E;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x939;&#x92E;&#x93E;&#x930;&#x940;&#x935;&#x947;&#x92C;&#x938;&#x93E;&#x907;&#x91F;&#x92F;&#x93E;&#x915;&#x942;&#x930;&#x93F;&#x92F;&#x930;&#x915;&#x940;&#x935;&#x947;&#x92C;&#x938;&#x93E;&#x907;&#x91F;&#x92A;&#x930;&#x905;&#x92A;&#x928;&#x947;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x915;&#x940;&#x92A;&#x94D;&#x930;&#x917;&#x924;&#x93F;&#x915;&#x94B;&#x91F;&#x94D;&#x930;&#x948;&#x915;&#x915;&#x930;&#x928;&#x947;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x915;&#x930;&#x938;&#x915;&#x924;&#x947;&#x939;&#x948;&#x902;&#x964;&#x915;&#x93F;&#x938;&#x940;&#x92D;&#x940;&#x938;&#x939;&#x93E;&#x92F;&#x924;&#x93E;&#x915;&#x947;&#x932;&#x93F;&#x90F;, &#x92C;&#x947;&#x91D;&#x93F;&#x91D;&#x915;&#x939;&#x92E;&#x93E;&#x930;&#x947;&#x917;&#x94D;&#x930;&#x93E;&#x939;&#x915;&#x938;&#x939;&#x93E;&#x92F;&#x924;&#x93E;&#x938;&#x947;&#x938;&#x902;&#x92A;&#x930;&#x94D;&#x915;&#x915;&#x930;&#x947;&#x902;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                                <h5 class="accordion-head A D F G H O">
                                                                    <span>&#x917;&#x94D;&#x930;&#x93E;&#x939;&#x915;&#x938;&#x947;&#x935;&#x93E;&#x938;&#x947;&#x915;&#x948;&#x938;&#x947;&#x938;&#x902;&#x92A;&#x930;&#x94D;&#x915;&#x915;&#x930;&#x947;&#x902;?</span>
                                                                    <span class="tatsu-accordion-expand"></span>
                                                                </h5>
                                                                <div class="bE">
                                                                    <div class="aE">
                                                                        <p>&#x939;&#x92E;&#x93E;&#x930;&#x940;&#x917;&#x94D;&#x930;&#x93E;&#x939;&#x915;&#x938;&#x939;&#x93E;&#x92F;&#x924;&#x93E;&#x91F;&#x940;&#x92E;&#x938;&#x947;1800-843-5599 &#x92A;&#x930;&#x938;&#x902;&#x92A;&#x930;&#x94D;&#x915;&#x915;&#x93F;&#x92F;&#x93E;&#x91C;&#x93E;&#x938;&#x915;&#x924;&#x93E;&#x939;&#x948;&#x964;&#x939;&#x92E;&#x938;&#x941;&#x92C;&#x939;10 &#x92C;&#x91C;&#x947;&#x938;&#x947;&#x936;&#x93E;&#x92E;5 &#x92C;&#x91C;&#x947;(&#x938;&#x94B;&#x92E;-&#x936;&#x928;&#x93F;) &#x915;&#x947;&#x92C;&#x940;&#x91A;&#x915;&#x93F;&#x938;&#x940;&#x92D;&#x940;&#x92A;&#x94D;&#x930;&#x936;&#x94D;&#x928;&#x92F;&#x93E;&#x91A;&#x93F;&#x902;&#x924;&#x93E;&#x92E;&#x947;&#x902;&#x906;&#x92A;&#x915;&#x940;&#x938;&#x939;&#x93E;&#x92F;&#x924;&#x93E;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x909;&#x92A;&#x932;&#x92C;&#x94D;&#x927;&#x939;&#x948;&#x902;&#x964;&#x906;&#x92A;&#x939;&#x92E;&#x947;&#x902;info@aswini.com &#x92A;&#x930;&#x908;&#x92E;&#x947;&#x932;&#x915;&#x947;&#x92E;&#x93E;&#x927;&#x94D;&#x92F;&#x92E;&#x938;&#x947;&#x92F;&#x93E;&#x939;&#x92E;&#x93E;&#x930;&#x940;&#x935;&#x947;&#x92C;&#x938;&#x93E;&#x907;&#x91F;&#x915;&#x947;&#x938;&#x902;&#x92A;&#x930;&#x94D;&#x915;&#x92B;&#x93C;&#x949;&#x930;&#x94D;&#x92E;&#x915;&#x947;&#x92E;&#x93E;&#x927;&#x94D;&#x92F;&#x92E;&#x938;&#x947;&#x92D;&#x940;&#x938;&#x902;&#x92A;&#x930;&#x94D;&#x915;&#x915;&#x930;&#x938;&#x915;&#x924;&#x947;&#x939;&#x948;&#x902;&#x964;</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-GKfEEnndPiq_ ID lD tatsu-section-offset wB">
                <div class="LD lD UB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-VaFKCAmcqG7U UD PD RD">
                                <div class="OD kD z">
                                    <div class="QD">
                                        <div class="WD lD tatsu-column-no-bg YD tatsu-5Z9hMlS80MqJ dD LC XC dC sC qC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-otFX14BtfaVT h2 eE tatsu-title-wrap-h2 u KB">
                                                            <h2 class="tatsu-title hE A C E G H K z V">&#x939;&#x93F;&#x930;&#x923;&#x926;&#x930;&#x94D;&#x926;&#x928;&#x93F;&#x935;&#x93E;&#x930;&#x915;&#x924;&#x947;&#x932;&#x938;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x915;&#x94B;&#x905;&#x932;&#x935;&#x93F;&#x926;&#x93E;&#x915;&#x939;&#x947;&#x902;!</h2>
                                                        </div>
                                                        <div class="tatsu-1yqY5yVchCs1 tatsu-module GE u KB bB">
                                                            <hr class="tatsu-module FE w">
                                                        </div>
                                                        <div class="tatsu-module tatsu-a5N-bWPLwqod h6 eE gE qE u">
                                                            <h6 class="tatsu-title hE z A D F G H P">&#x939;&#x93F;&#x930;&#x928;&#x926;&#x930;&#x94D;&#x926;&#x928;&#x93F;&#x935;&#x93E;&#x930;&#x915;&#x924;&#x947;&#x932;&#x938;&#x947;&#x91C;&#x94B;&#x921;&#x93C;&#x94B;&#x902;&#x915;&#x947;&#x926;&#x930;&#x94D;&#x926;&#x938;&#x947;&#x930;&#x93E;&#x939;&#x924;&#x92A;&#x93E;&#x90F;&#x902;&#x914;&#x930;&#x938;&#x915;&#x94D;&#x930;&#x93F;&#x92F;&#x926;&#x93F;&#x928;&#x94B;&#x902;&#x915;&#x93E;&#x906;&#x928;&#x902;&#x926;&#x932;&#x947;&#x902;</h6>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-oF9beNzN8GHU dD uB XC dC qC sC">
                                            <div class="tatsu-column-inner gradientClass cB tB">
                                                <div class="XD">
                                                    <div class="gD sB fC wC">
                                                        <div class="HE tatsu-module tatsu-BSZvLlkBPqkc qE jD tatsu-image-lazyload tatsu-BSZvLlkBPqkc EB">
                                                            <div class="tatsu-single-image-inner ZB gB jB">
                                                                <div class="tatsu-single-image-padding-wrap RC"></div>
                                                                <img data-srcset="https://media.swipepages.com/2023/3/5ff6c1a81bb3e30010dc353a/adityawebsite_12_1080x1296-150.webp 150w,https://media.swipepages.com/2023/3/5ff6c1a81bb3e30010dc353a/adityawebsite_12_1080x1296-300.webp 300w,https://media.swipepages.com/2023/3/5ff6c1a81bb3e30010dc353a/adityawebsite_12_1080x1296-500.webp 500w,https://media.swipepages.com/2023/3/5ff6c1a81bb3e30010dc353a/adityawebsite_12_1080x1296-750.webp 750w,https://media.swipepages.com/2023/3/5ff6c1a81bb3e30010dc353a/adityawebsite_12_1080x1296.webp 900w" sizes="(max-width: 767px) 100vw,(max-width: 1024px) 100vw,(max-width: 1377px) 533.6px, 533.6px" alt data-src="https://media.swipepages.com/2023/3/5ff6c1a81bb3e30010dc353a/adityawebsite_12_1080x1296.webp" data-webp="0">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD cB"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD a f mB"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-lEUXc7-96 ID lD tatsu-section-offset">
                <div class="LD lD SB">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-xzFztx6IKMme TD PD RD VD FD">
                                <div class="OD kD z rC">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-7dR-ucCjQEMg bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-v0-aRBws5C6Q tatsu-module mD MB">
                                                            <div class="hD tatsu-align-left HD i v z">
                                                                <p>
                                                                    <strong>&#x915;&#x908;&#x909;&#x92A;&#x92F;&#x94B;&#x917;&#x915;&#x930;&#x94D;&#x924;&#x93E;&#x913;&#x902;&#x926;&#x94D;&#x935;&#x93E;&#x930;&#x93E;5 &#x938;&#x94D;&#x91F;&#x93E;&#x930;&#x930;&#x947;&#x91F;&#x93F;&#x902;&#x917;&#x926;&#x940;&#x917;&#x908;</strong>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-NHRm1UsV5w_3 tatsu-module IE OE MB">
                                                            <div class="JE">
                                                                <div class="LE">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1189 6866 1190.9 6871.348 1196 6871.348 1191.838 6874.488 1193.327 6880 1189 6876.695 1184.675 6880 1186.162 6874.488 1182 6871.348 1187.1 6871.348" transform="translate(-1182 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                                <div class="KE o" style="width : 100%;">
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                    <span class="ME">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="15" viewBox="0 0 14 15">
                                                                            <polygon points="1170 6866 1171.9 6871.348 1177 6871.348 1172.838 6874.488 1174.327 6880 1170 6876.695 1165.675 6880 1167.162 6874.488 1163 6871.348 1168.1 6871.348" transform="translate(-1163 -6866)"/>
                                                                        </svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module tatsu-Hf65yUE_VKhQ tatsu-module mD">
                                                            <div class="hD tatsu-align-left HD v z">
                                                                <p>
                                                                    <span style="color: #000000;">
                                                                        <strong>&#x1F69A;&#x92E;&#x941;&#x92B;&#x93C;&#x94D;&#x924;&#x939;&#x94B;&#x92E;&#x921;&#x93F;&#x932;&#x940;&#x935;&#x930;&#x940;| &#x1F4B0;&#x938;&#x940;&#x913;&#x921;&#x940;&#x909;&#x92A;&#x932;&#x92C;&#x94D;&#x927;&#x939;&#x948;| &#x1F381;&#x905;&#x92D;&#x940;&#x932;&#x947;&#x902;11% &#x915;&#x940;&#x91B;&#x942;&#x91F;!</strong>
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="tatsu-module oD tD tatsu-JEsvaQJCEEns qE none B D S v LB">
                                                            <div class="qD YB UC WC">
                                                                <a class="tatsu-shortcode pD wD bg-animation-none left-icon sub-text" data-append-query-params="true" href="https://aswinishop.com/hi/cart/44057516933320:1">
                                                                    <div>
                                                                        <span class="rD DB eB MC VC" data-text="&#x916;&#x930;&#x940;&#x926;&#x947;&#x902; &#x938;&#x93F;&#x930;&#x94D;&#x92B; 239/- &#x92E;&#x947;&#x902;">
                                                                            <span class="default j">&#x916;&#x930;&#x940;&#x926;&#x947;&#x902;&#x938;&#x93F;&#x930;&#x94D;&#x92B;239/- &#x92E;&#x947;&#x902;</span>
                                                                        </span>
                                                                        <span class="sD Y j DB zB VC" data-text="&#x90F;&#x915; &#x92C;&#x942;&#x902;&#x926;, &#x924;&#x941;&#x930;&#x902;&#x924; &#x930;&#x93E;&#x939;&#x924;">
                                                                            <span class="default">&#x90F;&#x915;&#x92C;&#x942;&#x902;&#x926;, &#x924;&#x941;&#x930;&#x902;&#x924;&#x930;&#x93E;&#x939;&#x924;</span>
                                                                        </span>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
            <div class="tatsu-F1ggAASf0Ds3 ID lD tatsu-section-offset">
                <div class="LD lD FC">
                    <div class="tatsu-section-pad-inner">
                        <div class="MD">
                            <div class="aD be-preview lD tatsu-7Dk7EmYEjj76 TD PD RD VD">
                                <div class="OD kD z">
                                    <div class="QD">
                                        <div class="WD qE lD tatsu-column-no-bg ZD tatsu-Ckdbs8qeZPnQ bD z XC dC sC">
                                            <div class="tatsu-column-inner gradientClass">
                                                <div class="XD">
                                                    <div class="gD YC eC uC">
                                                        <div class="tatsu-module tatsu-KvxF1HPWVtu_ h1 eE tatsu-title-wrap-h1 v">
                                                            <h1 class="tatsu-title hE A C E G H J z EC T V">&#x930;&#x926;&#x94D;&#x926;&#x940;&#x915;&#x930;&#x923;&#x90F;&#x935;&#x902;&#x927;&#x928;&#x935;&#x93E;&#x92A;&#x938;&#x940;</h1>
                                                        </div>
                                                        <div class="tatsu-module tatsu-j9nETifu2rgH tatsu-module mD qE">
                                                            <div class="hD tatsu-align-left HD u z">
                                                                <ul>
                                                                    <li>
                                                                        &#x92F;&#x926;&#x93F;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x915;&#x94B;&#x928;&#x941;&#x915;&#x938;&#x93E;&#x928;&#x939;&#x94B;&#x924;&#x93E;&#x939;&#x948;, &#x924;&#x94B;&#x939;&#x92E;7 &#x926;&#x93F;&#x928;&#x94B;&#x902;&#x915;&#x947;&#x92D;&#x940;&#x924;&#x930;&#x905;&#x92A;&#x94D;&#x930;&#x92F;&#x941;&#x915;&#x94D;&#x924;&#x909;&#x924;&#x94D;&#x92A;&#x93E;&#x926;&#x94B;&#x902;&#x915;&#x940;&#x935;&#x93E;&#x92A;&#x938;&#x940;&#x938;&#x94D;&#x935;&#x940;&#x915;&#x93E;&#x930;&#x915;&#x930;&#x947;&#x902;&#x917;&#x947;&#x964;&#x90F;&#x915;&#x92C;&#x93E;&#x930;&#x91C;&#x92C;&#x939;&#x92E;&#x947;&#x902;&#x932;&#x94C;&#x91F;&#x93E;&#x908;&#x917;&#x908;&#x935;&#x938;&#x94D;&#x924;&#x941;&#x92A;&#x94D;&#x930;&#x93E;&#x92A;&#x94D;&#x924;&#x939;&#x94B;&#x91C;&#x93E;&#x90F;&#x917;&#x940;&#x924;&#x94B;&#x939;&#x92E;&#x930;&#x93F;&#x92B;&#x902;&#x921;&#x915;&#x940;&#x92A;&#x94D;&#x930;&#x915;&#x94D;&#x930;&#x93F;&#x92F;&#x93E;&#x915;&#x930;&#x947;&#x902;&#x917;&#x947;(&#x915;&#x942;&#x930;&#x93F;&#x92F;&#x930;&#x936;&#x941;&#x932;&#x94D;&#x915;&#x915;&#x94B;&#x91B;&#x94B;&#x921;&#x93C;&#x915;&#x930;)&#x964;<br>
                                                                        &#x911;&#x930;&#x94D;&#x921;&#x930;&#x926;&#x947;&#x928;&#x947;&#x915;&#x947;6 &#x918;&#x902;&#x91F;&#x947;&#x915;&#x947;&#x92D;&#x940;&#x924;&#x930;&#x930;&#x926;&#x94D;&#x926;&#x940;&#x915;&#x930;&#x923;&#x915;&#x940;&#x905;&#x928;&#x941;&#x92E;&#x924;&#x93F;&#x939;&#x948;&#x964;<br>&#x915;&#x943;&#x92A;&#x92F;&#x93E;&#x905;&#x92A;&#x928;&#x93E;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x930;&#x926;&#x94D;&#x926;&#x915;&#x930;&#x928;&#x947;&#x915;&#x947;&#x932;&#x93F;&#x90F;&#x939;&#x92E;&#x947;&#x902;&#x911;&#x930;&#x94D;&#x921;&#x930;&#x928;&#x902;&#x92C;&#x930;+91 9121390303 &#x92A;&#x930;&#x935;&#x94D;&#x939;&#x93E;&#x91F;&#x94D;&#x938;&#x90F;&#x92A;&#x915;&#x930;&#x947;&#x902;&#x964;
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="eD">
                                                    <div class="fD"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="KD">
                    <div class="JD"></div>
                </div>
                <div class="ND tatsu-section-overlay QB"></div>
            </div>
        </body>
        <input type="hidden" id="swipe-pages-variant" value="668fc6bd2d01450011199858">
        <input type="hidden" id="swipe-pages-page" value="668fc6bd2d01450011199850">
        <input type="hidden" id="swipe-pages-account" value="5ff6c1a81bb3e30010dc3538">
        <input type="hidden" id="swipe-pages-subaccount" value="5ff6c1a81bb3e30010dc353a">
        <script type="text/javascript" src="https://scripts.swipepages.com/js/jquery.min.js"></script>
        <script type="text/javascript" src="https://scripts.swipepages.com/js/vendor/asyncloader.min.js"></script>
        <script type="text/javascript" src="https://scripts.swipepages.com/js/helpers.min.js"></script>
        <script type="text/javascript">
            tatsuFrontendConfig = {
                apiBaseUrl: "https://app.swipepages.com/api",
                domain: "https://app.swipepages.com",
                asyncScripts: {
                    "anime": "https://scripts.swipepages.com/js/vendor/anime.min.js",
                    "asyncloader": "https://scripts.swipepages.com/js/vendor/asyncloader.min.js",
                    "begrid": "https://scripts.swipepages.com/js/vendor/begrid.min.js",
                    "countdown": "https://scripts.swipepages.com/js/vendor/countdown.min.js",
                    "countTo": "https://scripts.swipepages.com/js/vendor/countTo.min.js",
                    "exitIntent": "https://scripts.swipepages.com/js/vendor/exitIntent.min.js",
                    "fitvids": "https://scripts.swipepages.com/js/vendor/fitvids.min.js",
                    "flickity": "https://scripts.swipepages.com/js/vendor/flickity.min.js",
                    "isotope": "https://scripts.swipepages.com/js/vendor/isotope.min.js",
                    "jquery-ui": "https://scripts.swipepages.com/js/vendor/jquery-ui.min.js",
                    "magnificpopup": "https://scripts.swipepages.com/js/vendor/magnificpopup.min.js",
                    "swipe": "https://scripts.swipepages.com/js/vendor/swipe.min.js",
                    "tatsuCarousel": "https://scripts.swipepages.com/js/vendor/tatsuCarousel.min.js?ver=1.0.1",
                    "tatsuColumnParallax": "https://scripts.swipepages.com/js/vendor/tatsuColumnParallax.min.js",
                    "tatsuParallax": "https://scripts.swipepages.com/js/vendor/tatsuParallax.min.js",
                    "webfont": "https://scripts.swipepages.com/js/vendor/webfont.min.js",
                    "lifecycle.es5": "https://scripts.swipepages.com/js/vendor/lifecycle.es5.min.js"
                },
                gmapsAPIKey: "",
                goals: {
                    "formSubmission": false,
                    "links": ["https://aswinishop.com/collections/health-care/products/hiran-pain-relief-oil?utm_source=hiran_english_lp&utm_medium=landing&utm_campaign=hiran_english_lp_oct2023", "https://aswinishop.com/products/hiran-pain-relief-oil"],
                    "scrollDistance": null,
                    "timeSpent": null,
                    "linkClicks": true
                },

            };
            spAnalyticsConfig = {
                apiEndpoint: "https://events.swipepages.com/api/events"
            };
        </script>
        <!--sp-tracking-page-bodyClose-->
        <!-- Google Tag Manager (noscript) -->
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MJ26DFF" height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
        <!-- End Google Tag Manager (noscript) -->
        <!--/sp-tracking-page-bodyClose-->
        <script type="text/javascript">
            (function() {
                if (typeof window.swipeFormSubmitSuccess == "function") {
                    return;
                }
                window.swipeFormSubmitSuccess = function(lead) {
                    if (typeof fbq !== "function") {
                        return;
                    }
                    let lead_body = {}
                    if (lead && lead.email_sp) {
                        lead_body['em'] = lead.email_sp
                    }
                    if (lead && lead.phone_sp) {
                        lead_body['ph'] = lead.phone_sp
                    }
                    fbq('init', '304709863675708', lead_body)
                    fbq('track', 'Lead', lead_body, {
                        eventID: lead.id
                    });
                }
            }
            )()
        </script>
        <script type="text/javascript" src="/sp-events.js?ver=1.2"></script>
        <script type="text/javascript" src="https://scripts.swipepages.com/js/tatsu.min.js?ver=1.0.54"></script>
        <script async type="text/javascript" src="https://scripts.swipepages.com/js/analytics.min.js?ver=1.0.8"></script>
    </html>
